// ============================================================
//  server.mjs — ChatAI Browser Studio
//  v7 修正:
//   - Express 5 系の path-to-regexp 仕様変更に対応 (`*` → 名前付き `*splat`)
//   - 証明書が無い場合は自動的に HTTP で起動 (開発用)
//   - HOST / PORT 環境変数を尊重
//   - 静的ファイル配信時の Cache-Control を妥当な値に整理
// ============================================================
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import https from 'node:https';
import { fileURLToPath } from 'node:url';
import express from 'express';

const app = express();
app.use(express.json({ limit: '4mb' }));

// --- 簡易レート制限 (依存関係なし) ---
const rateLimitMap = new Map();
function simpleRateLimit(req, res, next) {
  const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  const now = Date.now();
  const windowMs = 15 * 60 * 1000; // 15分
  const maxRequests = 100;

  let info = rateLimitMap.get(ip);
  if (!info || (now - info.startTime) > windowMs) {
    info = { startTime: now, count: 1 };
  } else {
    info.count++;
  }
  rateLimitMap.set(ip, info);

  if (info.count > maxRequests) {
    return sendError(res, 429, 'リクエストが多すぎます。しばらくしてから再試行してください。');
  }
  next();
}
app.use('/api/', simpleRateLimit);

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = process.cwd();

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const LLM_BASE = process.env.LLM_BASE_URL || '';
const LLM_KEY = process.env.LLM_API_KEY || '';
const LLM_MODEL = process.env.LLM_MODEL || 'gpt-4o-mini';

function sendJson(res, status, obj) {
  res.status(status).set({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Cache-Control': 'no-store',
    'Content-Type': 'application/json; charset=utf-8',
  }).json(obj);
}

function sendError(res, status, message) {
  sendJson(res, status, { error: { message } });
}

function decodeEntities(s) {
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}

function stripHtml(html) {
  if (!html) return '';
  return decodeEntities(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
      .replace(/<header[\s\S]*?<\/header>/gi, ' ')
      .replace(/<nav[\s\S]*?<\/nav>/gi, ' ')
      .replace(/<footer[\s\S]*?<\/footer>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
  ).replace(/\s+/g, ' ').trim();
}

// ---- DuckDuckGo HTML 版 (POST) を使用 ----
async function ddgSearch(query, max = 8) {
  const endpoint = 'https://html.duckduckgo.com/html/';
  const q = String(query || '').trim();
  if (!q) return [];
  console.log(`[search] DDG: ${q}`);

  const doFetch = async () => fetch(endpoint, {
    method: 'POST',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'ja,en;q=0.8',
      'Content-Type': 'application/x-www-form-urlencoded',
      'Referer': 'https://duckduckgo.com/',
    },
    body: new URLSearchParams({ q, kl: 'jp-jp' }).toString(),
    redirect: 'follow',
  });

  try {
    let r = await doFetch();
    if (!r.ok) throw new Error(`DuckDuckGo HTML returned status ${r.status}`);
    let html = await r.text();

    if (html.includes('anomaly-modal') || /captcha/i.test(html)) {
      console.warn('[search] DDG CAPTCHA, fallback to lite');
      const liteUrl = `https://lite.duckduckgo.com/lite/?q=${encodeURIComponent(q)}`;
      const r2 = await fetch(liteUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept-Language': 'ja,en;q=0.8',
        },
        redirect: 'follow',
      });
      if (r2.ok) html = await r2.text();
      else return [];
      if (html.includes('anomaly-modal') || /captcha/i.test(html)) return [];
    }

    const results = [];
    const linkRe  = /<a\b[^>]*\bclass="[^"]*\bresult__a\b[^"]*"[^>]*\bhref="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    const linkRe2 = /<a\b[^>]*\bhref="([^"]+)"[^>]*\bclass="[^"]*\bresult__a\b[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;

    const matches = [];
    let m;
    while ((m = linkRe.exec(html)) !== null) matches.push({ idx: m.index, end: m.index + m[0].length, url: m[1], title: m[2] });
    while ((m = linkRe2.exec(html)) !== null) matches.push({ idx: m.index, end: m.index + m[0].length, url: m[1], title: m[2] });
    matches.sort((a, b) => a.idx - b.idx);

    const snippetRe = /class="[^"]*\bresult__snippet\b[^"]*"[^>]*>([\s\S]*?)<\/(?:a|div|td|span)>/i;

    const seen = new Set();
    for (const hit of matches) {
      if (results.length >= max) break;
      let finalUrl = hit.url;

      if (finalUrl.startsWith('//duckduckgo.com/l/?') || finalUrl.startsWith('/l/?')) {
        try {
          const u = new URL(finalUrl.startsWith('//') ? `https:${finalUrl}` : `https://duckduckgo.com${finalUrl}`);
          const real = u.searchParams.get('uddg');
          if (real) finalUrl = decodeURIComponent(real);
        } catch (e) {}
      }

      const title = stripHtml(hit.title);
      if (!title || !finalUrl || seen.has(finalUrl)) continue;
      seen.add(finalUrl);

      const tail = html.slice(hit.end, hit.end + 1500);
      const sm = tail.match(snippetRe);
      const snippet = sm ? stripHtml(sm[1]) : '';

      results.push({
        title: title.slice(0, 200),
        url: finalUrl,
        snippet: snippet.slice(0, 360),
      });
    }
    return results;
  } catch (e) {
    console.error(`[search] DDG error: ${e.message}`);
    return [];
  }
}

async function fetchUrl(target, maxBytes = 1_500_000) {
  const u = new URL(target);
  if (!/^https?:$/.test(u.protocol)) throw new Error('http(s) のみ対応');
  const isPrivate = /^(localhost|127\.|0\.0\.0\.0|10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.|169\.254\.|::1|fd[0-9a-f]{2}:|fe[89ab][0-9a-f]:)/i.test(u.hostname);
  if (isPrivate) {
    throw new Error('内部アドレスまたはプライベートIPへのアクセスは禁止されています');
  }

  const r = await fetch(target, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; ChatAIBrowserStudio/2.0)',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'ja,en;q=0.8',
    },
    redirect: 'follow',
  });

  const ct = r.headers.get('content-type') || '';
  const len = Number(r.headers.get('content-length') || '0');
  if (len && len > maxBytes) throw new Error('Response too large');

  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length > maxBytes) throw new Error('Response too large');

  const text = buf.toString('utf8').slice(0, 30000);
  const isHtml = /text\/html/i.test(ct) || /<html[\s>]/i.test(text);
  const tm = text.match(/<title[^>]*>([\s\S]*?)<\/title>/i);

  return {
    url: r.url,
    status: r.status,
    contentType: ct,
    title: tm ? stripHtml(tm[1]).slice(0, 200) : '',
    text: isHtml ? stripHtml(text).slice(0, 30000) : text,
  };
}

async function moderateViaLLM(text) {
  if (!LLM_BASE || !LLM_KEY) return { available: false };
  const r = await fetch(`${LLM_BASE.replace(/\/+$/, '')}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${LLM_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: LLM_MODEL,
      temperature: 0,
      max_tokens: 80,
      messages: [
        {
          role: 'system',
          content: 'あなたはAI回答の最終モデレーターです。次のテキストが (a)違法行為の助長 (b)未成年/非合意の性的描写 (c)具体的危害計画 (d)本人の自傷意志表明 のいずれかに当たるかだけを評価し、JSON 1行で返答せよ。形式: {"verdict":"ALLOW|CAUTION|BLOCK","reason":"..."}',
        },
        { role: 'user', content: text.slice(0, 1500) },
      ],
    }),
  });

  if (!r.ok) throw new Error(`LLM ${r.status}`);
  const data = await r.json();
  const out = data.choices?.[0]?.message?.content || '';
  const m = out.match(/\{[\s\S]*\}/);
  if (!m) return { available: true, verdict: 'ALLOW', reason: '' };
  try {
    return { available: true, ...JSON.parse(m[0]) };
  } catch {
    return { available: true, verdict: 'ALLOW', reason: '' };
  }
}

// ----- CORS / セキュリティヘッダ -----
app.use((req, res, next) => {
  // 開発環境以外では特定のオリジンに制限することを推奨
  const origin = req.headers.origin;
  res.set({
    'Access-Control-Allow-Origin': origin || '*', 
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    // CSPの強化: 'unsafe-inline' を最小限にし、不要な外部接続を制限
    'Content-Security-Policy': "default-src 'self'; " +
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://esm.sh https://cdn.jsdelivr.net https://cdn.run; " +
      "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; " +
      "img-src 'self' data: https: blob:; " +
      "connect-src 'self' https:; " +
      "worker-src 'self' blob:; " +
      "media-src 'self' blob: data:;",
  });
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// 静的ファイル配信
app.use(express.static(root, {
  setHeaders(res, filePath) {
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
    res.setHeader('Cross-Origin-Embedder-Policy', 'credentialless');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    const ext = path.extname(filePath);
    if (ext === '.html' || ext === '.webmanifest' || filePath.endsWith('sw.js')) {
      res.setHeader('Cache-Control', 'no-store');
    } else if (ext === '.js' || ext === '.css') {
      res.setHeader('Cache-Control', 'public, max-age=300, must-revalidate');
    } else {
      res.setHeader('Cache-Control', 'public, max-age=3600');
    }
  }
}));

// =========================================================
// /vendor/transformers プロキシ
//  Express 5: ワイルドカードは名前付き ":splat(*)" or "*splat" を使う
// =========================================================
const TRANSFORMERS_PKG = '@huggingface/transformers@3.0.2';
const VENDOR_BASE = `https://esm.sh/${TRANSFORMERS_PKG}`;

app.get(/^\/vendor\/transformers(\/.*)?$/, async (req, res) => {
  try {
    const sub = req.path.replace(/^\/vendor\/transformers/, '');
    const upstream = sub === '' || sub === '/' || sub === '/index.mjs'
      ? VENDOR_BASE
      : `${VENDOR_BASE}${sub}`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000); // 15s timeout
    const r = await fetch(upstream, {
      headers: {
        'User-Agent': 'ChatAIBrowserStudio/2.0 (vendor-proxy)',
        'Accept': '*/*',
      },
      redirect: 'follow',
      signal: controller.signal,
    }).finally(() => clearTimeout(timeout));
    const ct = r.headers.get('content-type') || 'application/javascript';
    let body = await r.text();

    if (ct.includes('javascript') || /\.m?js(\?|$)/.test(upstream)) {
      body = body
        .replace(/(['"])https:\/\/esm\.sh\//g, '$1/vendor/esm/')
        .replace(/(['"])\/v\d+\//g, '$1/vendor/esm/v_/');
    }

    res.set({
      'Content-Type': ct,
      'Cross-Origin-Resource-Policy': 'cross-origin',
      'Cross-Origin-Embedder-Policy': 'credentialless',
      'Cache-Control': 'public, max-age=600',
      'Access-Control-Allow-Origin': '*',
    });
    res.status(r.status).send(body);
  } catch (e) {
    sendError(res, 502, `vendor proxy failed: ${e.message}`);
  }
});

// esm.sh サブリソースのプロキシ
app.get(/^\/vendor\/esm(\/.*)?$/, async (req, res) => {
  try {
    const sub = req.path.replace(/^\/vendor\/esm/, '');
    const upstream = `https://esm.sh${sub}`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    const r = await fetch(upstream, { 
      redirect: 'follow',
      signal: controller.signal,
    }).finally(() => clearTimeout(timeout));
    const ct = r.headers.get('content-type') || 'application/javascript';
    if (/javascript|json|text/.test(ct)) {
      let body = await r.text();
      body = body
        .replace(/(['"])https:\/\/esm\.sh\//g, '$1/vendor/esm/')
        .replace(/(['"])\/v\d+\//g, '$1/vendor/esm/v_/');
      res.set({
        'Content-Type': ct,
        'Cross-Origin-Resource-Policy': 'cross-origin',
        'Cross-Origin-Embedder-Policy': 'credentialless',
        'Cache-Control': 'public, max-age=600',
        'Access-Control-Allow-Origin': '*',
      });
      return res.status(r.status).send(body);
    } else {
      const buf = Buffer.from(await r.arrayBuffer());
      res.set({
        'Content-Type': ct,
        'Cross-Origin-Resource-Policy': 'cross-origin',
        'Cross-Origin-Embedder-Policy': 'credentialless',
        'Cache-Control': 'public, max-age=600',
        'Access-Control-Allow-Origin': '*',
      });
      return res.status(r.status).send(buf);
    }
  } catch (e) {
    sendError(res, 502, `esm proxy failed: ${e.message}`);
  }
});

app.get('/api/tools/list', (req, res) => {
  sendJson(res, 200, {
    tools: [
      {
        name: 'web_search',
        description: 'DuckDuckGo を使ったWeb検索。日本語可。',
        inputSchema: {
          type: 'object',
          properties: { query: { type: 'string' }, max: { type: 'number' } },
          required: ['query'],
        },
      },
      {
        name: 'fetch_url',
        description: '任意のURLをサーバー経由で取得し本文を返す（CORS無視）。',
        inputSchema: {
          type: 'object',
          properties: { url: { type: 'string' } },
          required: ['url'],
        },
      },
      {
        name: 'moderate',
        description: '外部LLMで最終モデレーション（環境変数 LLM_API_KEY 必須）。',
        inputSchema: {
          type: 'object',
          properties: { text: { type: 'string' } },
          required: ['text'],
        },
        available: Boolean(LLM_BASE && LLM_KEY),
      },
    ],
  });
});

function decodeBingRedirect(href) {
  if (!href) return href;
  try {
    const u = new URL(href, 'https://www.bing.com');
    if (!/(^|\.)bing\.com$/i.test(u.hostname)) return href;
    if (!/\/ck\/a/i.test(u.pathname)) return href;
    const raw = u.searchParams.get('u');
    if (!raw) return href;
    let payload = raw.startsWith('a1') ? raw.slice(2) : raw;
    payload = payload.replace(/-/g, '+').replace(/_/g, '/');
    while (payload.length % 4) payload += '=';
    const decoded = Buffer.from(payload, 'base64').toString('utf8');
    if (/^https?:\/\//i.test(decoded)) return decoded;
    return href;
  } catch {
    return href;
  }
}

async function bingSearch(query, max = 8) {
  const q = String(query || '').trim();
  if (!q) return [];
  const url = `https://www.bing.com/search?q=${encodeURIComponent(q)}&setlang=ja&cc=JP&form=QBLH`;
  console.log(`[search] Bing: ${q}`);

  try {
    const r = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'ja,en;q=0.8',
      },
      redirect: 'follow',
    });
    if (!r.ok) throw new Error(`Bing returned ${r.status}`);
    const html = await r.text();

    const results = [];
    const seen = new Set();
    const blockRe = /<li[^>]*class="b_algo"[^>]*>([\s\S]*?)<\/li>/gi;
    let m;
    while ((m = blockRe.exec(html)) && results.length < max) {
      const block = m[1];
      const linkM = block.match(/<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
      if (!linkM) continue;
      const title = stripHtml(linkM[2]);
      const rawUrl = decodeEntities(linkM[1]);
      const finalUrl = decodeBingRedirect(rawUrl);
      const snipM = block.match(/<p[^>]*>([\s\S]*?)<\/p>/i)
                 || block.match(/class="b_caption"[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/i);
      const snippet = snipM ? stripHtml(snipM[1]) : '';
      if (title && finalUrl && /^https?:/i.test(finalUrl) && !seen.has(finalUrl)) {
        seen.add(finalUrl);
        results.push({
          title: title.slice(0, 200),
          url: finalUrl,
          snippet: snippet.slice(0, 360),
        });
      }
    }
    return results;
  } catch (e) {
    console.error(`[search] Bing error: ${e.message}`);
    return [];
  }
}

app.post('/api/tools/web_search', async (req, res) => {
  try {
    const body = req.body || {};
    const q = String(body.query || '');
    const max = Number(body.max || 8);
    let results = await ddgSearch(q, max);
    let provider = 'duckduckgo';
    if (!results.length) {
      results = await bingSearch(q, max);
      provider = 'bing';
    }
    sendJson(res, 200, { results, provider });
  } catch (e) {
    sendError(res, 500, e.message);
  }
});

app.post('/api/tools/fetch_url', async (req, res) => {
  try {
    const body = req.body || {};
    const out = await fetchUrl(String(body.url || ''));
    sendJson(res, 200, out);
  } catch (e) {
    sendError(res, 500, e.message);
  }
});

app.post('/api/tools/moderate', async (req, res) => {
  try {
    const body = req.body || {};
    const out = await moderateViaLLM(String(body.text || ''));
    sendJson(res, 200, out);
  } catch (e) {
    sendError(res, 500, e.message);
  }
});

app.get('/api/health', (req, res) => {
  sendJson(res, 200, { ok: true, llmModeration: Boolean(LLM_BASE && LLM_KEY) });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(root, 'index.html'));
});

// 404 ハンドラ (Express 5 互換)
app.use((req, res) => {
  sendError(res, 404, 'Not found');
});

// ============================================================
// HTTPS / HTTP 起動
//  証明書 (mkcert で出力した *.pem) が cwd にあれば HTTPS、無ければ HTTP
// ============================================================
const dir = process.cwd();
let keyFile = null;
let certFile = null;
try {
  const entries = fs.readdirSync(dir);
  keyFile  = entries.find(f => /key/.test(f) && f.endsWith('.pem'));
  certFile = entries.find(f => f.endsWith('.pem') && !/key/.test(f));
} catch {}

function logRoutes(scheme) {
  console.log(`\n  ChatAI Browser Studio — ${scheme}://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
  console.log('   /api/health');
  console.log('   /api/tools/list');
  console.log('   /api/tools/web_search');
  console.log('   /api/tools/fetch_url');
  console.log(`   /api/tools/moderate ... ${LLM_BASE && LLM_KEY ? 'enabled' : 'disabled (set LLM_API_KEY)'}`);
  console.log();
}

if (keyFile && certFile) {
  try {
    const options = {
      key:  fs.readFileSync(path.join(dir, keyFile)),
      cert: fs.readFileSync(path.join(dir, certFile)),
    };
    https.createServer(options, app).listen(PORT, HOST, () => logRoutes('https'));
  } catch (e) {
    console.warn(`HTTPS 起動に失敗 (${e.message})。HTTP にフォールバックします。`);
    http.createServer(app).listen(PORT, HOST, () => logRoutes('http'));
  }
} else {
  console.log('TLS 証明書 (*.pem) が見つからないので HTTP で起動します。\n  HTTPS にしたい場合は mkcert などで証明書を作成し、同じディレクトリに配置してください。');
  http.createServer(app).listen(PORT, HOST, () => logRoutes('http'));
}
