import { STORAGE_KEYS } from './config.js';
import { DEFAULT_SESSION, DEFAULT_SETTINGS } from './defaults.js';

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : structuredClone(fallback);
  } catch {
    return structuredClone(fallback);
  }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function loadSettings() {
  return { ...structuredClone(DEFAULT_SETTINGS), ...load(STORAGE_KEYS.settings, DEFAULT_SETTINGS) };
}

export function saveSettings(settings) {
  save(STORAGE_KEYS.settings, settings);
}

/**
 * セッションオブジェクトを正規化して不正な形式を防ぐ
 */
export function normalizeSession(session) {
  if (!session || typeof session !== 'object' || !Array.isArray(session.messages)) {
    return structuredClone(DEFAULT_SESSION);
  }
  return {
    ...structuredClone(DEFAULT_SESSION),
    ...session,
    messages: session.messages.filter(m => m && typeof m === 'object' && m.role),
    summary: session.summary ?? '',
    attachments: Array.isArray(session.attachments) ? session.attachments : [],
  };
}

export function loadSession() {
  const session = load(STORAGE_KEYS.session, DEFAULT_SESSION);
  return normalizeSession(session);
}

export function saveSession(session) {
  save(STORAGE_KEYS.session, session);
}

export function loadKnowledgeBase() {
  return load(STORAGE_KEYS.knowledge, { items: [] });
}

export function saveKnowledgeBase(knowledgeBase) {
  save(STORAGE_KEYS.knowledge, knowledgeBase);
}

export function loadMcpState() {
  return load(STORAGE_KEYS.mcp, { endpoint: '', enabled: false, tools: [] });
}

export function saveMcpState(state) {
  save(STORAGE_KEYS.mcp, state);
}
