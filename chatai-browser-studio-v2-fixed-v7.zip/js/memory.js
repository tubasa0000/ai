import { CDN, EMBEDDING_MODEL } from './config.js';
import { chunkText, cosineSimilarity, createId } from './utils.js';

let transformersModulePromise;
async function getTransformers() {
  if (!transformersModulePromise) {
    transformersModulePromise = (async () => {
      const mod = await import(CDN.transformers);
      try {
        const env = mod.env;
        if (env) {
          env.allowLocalModels = false;
          env.useBrowserCache = true;
          if (env.backends?.onnx?.wasm) {
            env.backends.onnx.wasm.proxy = false;
            env.backends.onnx.wasm.numThreads = 1;
          }
        }
      } catch (e) {
        console.warn('transformers env tweak failed:', e);
      }
      return mod;
    })();
  }
  return await transformersModulePromise;
}

export class MemoryManager {
  constructor(loadKnowledge, saveKnowledge, settingsProvider) {
    this.loadKnowledge = loadKnowledge;
    this.saveKnowledge = saveKnowledge;
    this.settingsProvider = settingsProvider;
    this.extractor = null;
  }

  async ensureExtractor() {
    if (this.extractor) return this.extractor;
    const { pipeline } = await getTransformers();
    const settings = this.settingsProvider ? this.settingsProvider() : { disableWebGpu: false };
    const useGpu = navigator.gpu && !settings.disableWebGpu;
    try {
      this.extractor = await pipeline('feature-extraction', EMBEDDING_MODEL, {
        device: useGpu ? 'webgpu' : 'wasm',
      });
    } catch (e) {
      console.warn('Embedding WebGPU failed, falling back to wasm:', e);
      this.extractor = await pipeline('feature-extraction', EMBEDDING_MODEL, {
        device: 'wasm',
      });
    }
    return this.extractor;
  }

  async embedText(text) {
    const extractor = await this.ensureExtractor();
    const output = await extractor(text, { pooling: 'mean', normalize: true });
    const raw = output.tolist ? output.tolist() : output;
    if (Array.isArray(raw?.[0])) return raw[0];
    if (Array.isArray(raw)) return raw;
    return Array.from(output.data || []);
  }

  async addText(text, meta = {}) {
    const kb = this.loadKnowledge();
    const chunks = chunkText(text, 520, 64);
    for (const chunk of chunks) {
      const embedding = await this.embedText(chunk);
      kb.items.push({
        id: createId('kb'),
        text: chunk,
        embedding,
        createdAt: new Date().toISOString(),
        ...meta,
      });
    }
    this.saveKnowledge(kb);
    return kb.items.length;
  }

  async retrieveRelevant(query, k = 4) {
    const kb = this.loadKnowledge();
    if (!kb.items?.length || !query?.trim()) return [];
    const embedding = await this.embedText(query);
    return kb.items
      .map((item) => ({ ...item, score: cosineSimilarity(item.embedding, embedding) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, k)
      .filter((item) => item.score > 0.2);
  }

  async rebuildAllEmbeddings() {
    const kb = this.loadKnowledge();
    for (const item of kb.items) {
      item.embedding = await this.embedText(item.text);
    }
    this.saveKnowledge(kb);
    return kb.items.length;
  }

  async extractAndStoreFacts(text, source = 'conversation') {
    const lines = String(text || '')
      .split(/[。\n]/)
      .map((line) => line.trim())
      .filter(Boolean);
    const candidates = lines.filter((line) => /(好き|嫌い|住んで|誕生日|趣味|仕事|職業|呼んで|名前|推し|大事|覚えて)/.test(line));
    if (!candidates.length) return 0;
    const joined = candidates.join('。');
    await this.addText(joined, { type: 'memory', source });
    return candidates.length;
  }
}
