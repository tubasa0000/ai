// ============================================================
//  node-tools.js
//  同梱の Node サーバー(server.mjs) が提供するツールへのクライアント。
//  - web_search / fetch_url / moderate
//  - 自身を統一インターフェイス {name, description, invoke} で公開
// ============================================================

const DEFAULT_BASE = '';   // 同一オリジンに同梱されている前提

export class NodeToolClient {
  constructor(base = DEFAULT_BASE) {
    this.base = base.replace(/\/+$/, '');
    this.available = false;
    this.tools = [];
  }

  async probe() {
    try {
      const r = await fetch(`${this.base}/api/tools/list`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      this.tools = data.tools || [];
      this.available = true;
      return this.tools;
    } catch {
      this.available = false;
      this.tools = [];
      return [];
    }
  }

  async _post(path, body) {
    const r = await fetch(`${this.base}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
    });
    const ct = r.headers.get('content-type') || '';
    const text = await r.text();
    if (!r.ok) {
      let msg = text;
      if (ct.includes('application/json')) {
        try { msg = JSON.parse(text).error?.message || text; } catch {}
      }
      throw new Error(`${path} ${r.status}: ${msg}`);
    }
    return ct.includes('application/json') ? JSON.parse(text) : text;
  }

  webSearch(query, max = 8) {
    return this._post('/api/tools/web_search', { query, max });
  }

  fetchUrl(url) {
    return this._post('/api/tools/fetch_url', { url });
  }

  moderateExternal(text) {
    return this._post('/api/tools/moderate', { text });
  }

  // モデル向けの呼び出し用テーブル
  toolList() {
    return this.tools.map((t) => ({
      name: t.name,
      description: t.description,
      inputSchema: t.inputSchema,
      origin: 'node',
      available: t.available !== false,
    }));
  }

  async invoke(name, args = {}) {
    switch (name) {
      case 'web_search':
        return this.webSearch(args.query, args.max ?? 6);
      case 'fetch_url':
        return this.fetchUrl(args.url);
      case 'moderate':
        return this.moderateExternal(args.text);
      default:
        throw new Error(`未知のツール: ${name}`);
    }
  }
}
