// ============================================================
// adapters.js — WebLLM / Wllama 安定版
// 修正点:
//  ・GGUF アーキテクチャを事前検出し、wllama 未対応 (lfm2 等) ならわかりやすく失敗
//  ・messages を必ず正規化 ({role, content} の配列であることを保証)
//  ・HF CDN 取得失敗 (ERR_CONNECTION_RESET 等) は最大3回リトライ
//  ・progress 安定化
// ============================================================

import { CDN, WLLAMA_SUPPORTED_ARCHS } from './config.js';

// ---------------- 共通: messages 正規化 ----------------
function normalizeMessages(messages) {
  if (!Array.isArray(messages)) {
    throw new TypeError(`messages must be an array, got ${typeof messages}`);
  }
  const out = [];
  for (const m of messages) {
    if (!m || typeof m !== 'object') continue;
    const role = typeof m.role === 'string' ? m.role : 'user';
    let content = m.content;
    if (content == null) content = '';
    if (typeof content !== 'string') {
      try { content = String(content); } catch { content = ''; }
    }
    out.push({ role, content });
  }
  if (!out.length) {
    out.push({ role: 'user', content: '' });
  }
  return out;
}

// ---------------- Manager ----------------
export class AdapterManager {
  constructor() {
    this.adapter = null;
    this.abortController = null;
  }

  async load(settings, onStatus) {
    this.abortController = null;

    if (settings.provider === 'webllm') {
      this.adapter = new WebLLMAdapter();
    } else {
      this.adapter = new WllamaAdapter();
    }

    await this.adapter.load(settings, onStatus);
    return this.adapter;
  }

  async *streamChat(messages, options = {}) {
    if (!this.adapter) throw new Error('モデル未ロード');

    const normalized = normalizeMessages(messages);
    this.abortController = new AbortController();

    for await (const chunk of this.adapter.streamChat(normalized, {
      ...options,
      abortSignal: this.abortController.signal,
    })) {
      yield chunk;
    }
  }

  stop() {
    this.abortController?.abort?.();
    this.adapter?.stop?.();
  }

  isLoaded() {
    return Boolean(this.adapter?.loaded);
  }

  getLabel() {
    return this.adapter?.label || '未ロード';
  }
}

// ============================================================
// WebLLM
// ============================================================
class WebLLMAdapter {
  constructor() {
    this.engine = null;
    this.loaded = false;
    this.label = 'WebLLM';
  }

  async load(settings, onStatus) {
    if (!navigator.gpu || settings.disableWebGpu) {
      throw new Error(settings.disableWebGpu ? 'WebGPUは設定で無効化されています' : 'WebGPU未対応ブラウザ（Chrome推奨）');
    }

    const webllm = await import(CDN.webllm);

    let model = settings.webllmModel;

    const options = {
      initProgressCallback: (p) => {
        const percent = Math.round((p?.progress || 0) * 100);
        onStatus?.(`WebLLM読込中: ${p?.text || percent + '%'}`);
      },
    };

    if (settings.customWebllmRecord?.trim()) {
      const record = JSON.parse(settings.customWebllmRecord);
      options.appConfig = { model_list: [record] };
      model = record.model_id || model;
    }

    this.engine = await webllm.CreateMLCEngine(model, options);
    this.loaded = true;
    this.label = `WebLLM: ${model}`;
  }

  async *streamChat(messages, options) {
    const stream = await this.engine.chat.completions.create({
      messages,
      temperature: options.temperature,
      top_p: options.topP,
      max_tokens: options.maxTokens,
      stream: true,
    });

    for await (const chunk of stream) {
      if (options.abortSignal?.aborted) {
        throw new DOMException('Aborted', 'AbortError');
      }
      const delta = chunk?.choices?.[0]?.delta?.content || '';
      if (delta) yield delta;
    }
  }

  stop() {}
}

// ============================================================
// Wllama
// ============================================================
const SHARD_RE = /-(\d{3,5})-of-(\d{3,5})\.gguf$/i;
const PART_RE  = /\.gguf\.part(\d+)$/i;

function isShardName(name) {
  return SHARD_RE.test(name) || PART_RE.test(name);
}

// GGUF ヘッダーを先頭だけ読んで general.architecture 文字列を取り出す。
// 失敗時は null を返す (=判定不能なので素通し)。
//   GGUF v3 仕様:
//     magic(4) "GGUF" | version(uint32) | tensor_count(uint64) | metadata_kv_count(uint64) |
//     [ key_len(uint64) key_bytes | value_type(uint32) value... ] × kv_count
//   architecture は最初の方の KV にある事が多いので先頭 256KB だけスキャンする。
async function detectGgufArchitecture(arrayBuffer) {
  try {
    const view = new DataView(arrayBuffer);
    const bytes = new Uint8Array(arrayBuffer);
    if (bytes.length < 16) return null;
    const magic = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]);
    if (magic !== 'GGUF') return null;

    // 全部パースするのは大変なので、UTF-8 で "general.architecture" を探して、
    // 直後の value (type=8: string) を取り出す。
    const KEY = 'general.architecture';
    const keyBytes = new TextEncoder().encode(KEY);
    let idx = -1;
    outer: for (let i = 16; i < bytes.length - keyBytes.length - 16; i++) {
      for (let j = 0; j < keyBytes.length; j++) {
        if (bytes[i + j] !== keyBytes[j]) continue outer;
      }
      idx = i;
      break;
    }
    if (idx < 0) return null;
    // key の直後: value_type(uint32 LE) + value_len(uint64 LE) + value_bytes
    let p = idx + keyBytes.length;
    if (p + 12 > bytes.length) return null;
    const valueType = view.getUint32(p, true); p += 4;
    if (valueType !== 8) return null; // 8 = string
    const lenLo = view.getUint32(p, true);
    const lenHi = view.getUint32(p + 4, true);
    p += 8;
    const valLen = lenHi === 0 ? lenLo : Number((BigInt(lenHi) << 32n) | BigInt(lenLo));
    if (!Number.isFinite(valLen) || valLen <= 0 || valLen > 64 || p + valLen > bytes.length) return null;
    const arch = new TextDecoder().decode(bytes.slice(p, p + valLen));
    return arch.trim().toLowerCase();
  } catch {
    return null;
  }
}

// 最大 maxBytes だけ HTTP Range で取得 (ヘッダー判定用)
async function fetchHeadBytes(url, maxBytes = 262144) {
  const r = await fetch(url, {
    headers: { 'Range': `bytes=0-${maxBytes - 1}` },
    cache: 'no-store',
  });
  if (!r.ok && r.status !== 206) throw new Error(`HF range fetch failed: ${r.status}`);
  return await r.arrayBuffer();
}

async function readBlobHead(file, maxBytes = 262144) {
  const slice = file.slice(0, Math.min(maxBytes, file.size));
  return await slice.arrayBuffer();
}

function archUnsupportedMessage(arch) {
  return `このGGUFのアーキテクチャ "${arch}" は現在の Wllama (llama.cpp WASM) ではまだ対応していません。\n`
    + `→ プリセットから対応モデル (例: Qwen2.5-1.5B-Instruct-GGUF, Llama-3.2-1B-Instruct-GGUF) を選択するか、\n`
    + `   別のリポジトリの GGUF を指定してください。\n`
    + `(参考: 既知未対応 = lfm2, mamba, jamba 等)`;
}

class WllamaAdapter {
  constructor() {
    this.wllama = null;
    this.loaded = false;
    this.label = 'Wllama';
  }

  async load(settings, onStatus) {
    const [{ Wllama }, wasmModule] = await Promise.all([
      import(CDN.wllama),
      import(CDN.wllamaWasm),
    ]);

    this.wllama = new Wllama({
      default: wasmModule.default['multi-thread/wllama.wasm'] || wasmModule.default['single-thread/wllama.wasm'],
      'multi-thread/wllama.wasm': wasmModule.default['multi-thread/wllama.wasm'],
      'single-thread/wllama.wasm': wasmModule.default['single-thread/wllama.wasm'],
    });

    const normalizeProgress = (p) => {
      let percent = 0;
      if (typeof p?.progress === 'number' && Number.isFinite(p.progress)) {
        percent = p.progress <= 1 ? p.progress * 100 : p.progress;
      } else if (
        typeof p?.loaded === 'number' &&
        typeof p?.total === 'number' &&
        p.total > 0
      ) {
        percent = (p.loaded / p.total) * 100;
      }
      if (!Number.isFinite(percent)) percent = 0;
      return Math.min(100, Math.max(0, Math.round(percent)));
    };

    const localFiles = Array.from(settings.localGgufFiles || []);

    // ===== ローカルから =====
    if (localFiles.length >= 1) {
      const sorted = [...localFiles].sort((a, b) => a.name.localeCompare(b.name));

      onStatus?.(
        sorted.length > 1
          ? `ローカル分割GGUF (${sorted.length}ファイル) を読み込み中`
          : 'ローカルGGUFを読み込み中'
      );

      // アーキ事前チェック
      try {
        onStatus?.('GGUFヘッダーを検査中…');
        const head = await readBlobHead(sorted[0]);
        const arch = await detectGgufArchitecture(head);
        if (arch && !WLLAMA_SUPPORTED_ARCHS.has(arch)) {
          throw new Error(archUnsupportedMessage(arch));
        }
        if (arch) onStatus?.(`アーキ検出: ${arch} (OK)`);
      } catch (e) {
        // 検査自体は致命ではないが、 unsupported は throw する
        if (String(e?.message || '').includes('対応していません')) throw e;
      }

      const progressCallback = (p) =>
        onStatus?.(`GGUF読込中: ${normalizeProgress(p)}%`);

      try {
        if (typeof this.wllama.loadModel === 'function') {
          await this.wllama.loadModel(sorted, { progressCallback });
        } else if (typeof this.wllama.loadModelFromUrl === 'function') {
          const urls = sorted.map((f) => URL.createObjectURL(f));
          try {
            await this.wllama.loadModelFromUrl(urls.length === 1 ? urls[0] : urls, {
              progressCallback,
            });
          } finally {
            urls.forEach((u) => URL.revokeObjectURL(u));
          }
        } else {
          throw new Error('Wllama: loadModel / loadModelFromUrl が見つかりません');
        }
      } catch (err) {
        throw new Error(`ローカルGGUF読込失敗: ${err?.message || err}`);
      }

      this.label = `Wllama: ${sorted[0].name}${
        sorted.length > 1 ? ` (+${sorted.length - 1} shards)` : ''
      }`;
      this.loaded = true;
      return;
    }

    // ===== HF から =====
    onStatus?.('Hugging Face からGGUFを取得中');

    const repo = String(settings.hfRepo || '').trim();
    const file = String(settings.hfFile || '').trim();
    if (!repo || !file) {
      throw new Error('Hugging Face の repo / file が未設定です');
    }

    // アーキ事前チェック (Range で先頭だけ取得)
    try {
      onStatus?.('GGUFヘッダーを検査中…');
      const headUrl = `https://huggingface.co/${repo}/resolve/main/${encodeURIComponent(file)}`;
      const head = await fetchHeadBytes(headUrl, 262144);
      const arch = await detectGgufArchitecture(head);
      if (arch && !WLLAMA_SUPPORTED_ARCHS.has(arch)) {
        throw new Error(archUnsupportedMessage(arch));
      }
      if (arch) onStatus?.(`アーキ検出: ${arch} (OK)`);
    } catch (e) {
      // unsupported は throw、それ以外は素通し (HF Range が効かないケースもあるので)
      if (String(e?.message || '').includes('対応していません')) throw e;
      console.warn('GGUF arch precheck skipped:', e?.message || e);
    }

    const progressCb = (p) =>
      onStatus?.(`GGUF読込中: ${normalizeProgress(p)}%`);

    // 最大 3 回までリトライ (HF CDN の ERR_CONNECTION_RESET 等への耐性)
    const MAX_RETRY = 3;
    let lastErr;
    for (let i = 0; i < MAX_RETRY; i++) {
      try {
        await this.wllama.loadModelFromHF(repo, file, {
          progressCallback: progressCb,
          parallelDownloads: 2,
          fetchConfig: {
            cache: 'no-store',
            mode: 'cors',
          },
        });
        lastErr = null;
        break;
      } catch (err) {
        lastErr = err;
        const msg = String(err?.message || err);
        if (msg.includes('magic number')) {
          throw new Error('GGUFファイルが破損しています。ブラウザのキャッシュをクリアして再試行してください。');
        }
        if (msg.includes('unknown model architecture') || msg.includes('Invalid typed array length')) {
          throw new Error(`HF GGUF読込失敗: ${msg}\n\n${archUnsupportedMessage('(未確定)')}`);
        }
        if (i < MAX_RETRY - 1) {
          onStatus?.(`取得失敗、リトライ ${i + 2}/${MAX_RETRY}: ${msg.slice(0, 80)}`);
          await new Promise((r) => setTimeout(r, 1500 * (i + 1)));
        }
      }
    }
    if (lastErr) throw new Error(`HF GGUF読込失敗: ${lastErr?.message || lastErr}`);

    this.label = `Wllama: ${repo}/${file}${isShardName(file) ? ' (auto-shards)' : ''}`;
    this.loaded = true;
  }

  async *streamChat(messages, options) {
    const maxTokens = Math.min(options.maxTokens || 1024, 2048);

    const stream = await this.wllama.createChatCompletion({
      messages,
      temperature: options.temperature,
      top_p: options.topP,
      max_tokens: maxTokens,
      stream: true,
      abortSignal: options.abortSignal,
    });

    for await (const chunk of stream) {
      const text = chunk?.choices?.[0]?.delta?.content || '';
      if (text) yield text;
    }
  }

  stop() {
    this.wllama?.abort?.();
  }
}
