import {
  DEFAULT_GGUF_FILE,
  DEFAULT_GGUF_REPO,
  DEFAULT_IMAGE_CAPTION_MODEL,
  PRESET_WEBLLM_MODELS,
} from './config.js';

export const DEFAULT_SYSTEM_PROMPT = `あなたはブラウザ内で動作するAIアシスタントです。以下を必ず守り、誠実に動作してください。

1. ユーザーの明示的な指示を最優先する。
2. 危害・違法行為・差別を助長しない。だが「特定の単語が含まれている」という理由だけで会話を拒否しない。曲名・作品名・歴史・統計・予防啓発など正当な言及は普通に扱う。
3. 【不確かさと取り扱い】
   ・ユーザーの質問や文脈が明確に理解できないときは、推測で答えず「理解できない点」を示してユーザーに確認する。
   ・回答が正確でない可能性が高い場合 (最新情報/未検証/記憶にない事柄) は、データを捏造したり推測を断定的に語らない。
   ・必要に応じて web_search ツールを使い、検索結果が不十分ならクエリを変えて複数回検索してよい。検索しても不明なら「不明」と明言し、それでも答えられる範囲だけ述べる。
4. 【ツール使用】
   ・検索 (web_search) / URL取得 (fetch_url) などのツールが利用可能な場合は、事実確認が必要な質問では積極的に使う。
   ・一度の検索で不十分なら、別の表現・より狭い/広いキーワードで再検索してよい (最大ラウンド数まで)。
   ・回答の途中でも不明点が出たら、その都度 [TOOL_CALL]…[/TOOL_CALL] で検索・価値チェックしてから続けてよい。
5. 医療・法律・金融・安全工学では一般情報として答え、必要なら専門家相談を勧める。
6. 回答は丁寧で簡潔、必要に応じて段階的に。日本語で答える。
7. 会話履歴の送信日時と文脈を尊重する。`;

export const DEFAULT_CONVERSATION_RULES = `- ユーザーが砕けた口調でも尊重を保つ。
- 性的・暴力的話題は文脈を見て判断。文化・歴史・統計・予防啓発など正当な文脈は通す。
- スクレイピングや外部アクセスは相手先の利用規約に配慮する。
- 自分の知識の限界は素直に伝える。憶測で埋めない。`;

export const DEFAULT_SETTINGS = {
  provider: 'wllama',
  hfRepo: DEFAULT_GGUF_REPO,
  hfFile: DEFAULT_GGUF_FILE,
  webllmModel: PRESET_WEBLLM_MODELS[0],
  customWebllmRecord: '',
  temperature: 0.7,
  topP: 0.9,
  maxTokens: 768,
  contextBudget: 4096,
  maxTurns: 24,
  retrievalK: 4,
  compressionStrategy: 'summary+rag',
  speechInputEngine: 'browser',
  ttsEngine: 'browser',
  ttsVoiceURI: '',
  ttsRate: 1,
  ttsPitch: 1,

  // モデレーション
  allowSexualContent: false,
  allowViolence: false,
  strictMedical: true,
  blockUnsafeTts: true,
  streamTts: true,
  aiModeration: true,
  useNodeModeration: false,

  systemPrompt: DEFAULT_SYSTEM_PROMPT,
  conversationRules: DEFAULT_CONVERSATION_RULES,

  // MCP / Node ツール
  mcpEndpoint: '',
  mcpEnabled: false,
  autoToolCalls: true,
  toolCallRounds: 4,
  useNodeTools: true,
  forceSearch: false,
  searchTopK: 6,

  // 画像キャプション
  imageCaptionModel: DEFAULT_IMAGE_CAPTION_MODEL,
  refineCaptionWithLLM: true,

  // ハードウェア
  disableWebGpu: false,

  // UI / A11y
  theme: 'auto',                  // auto / dark / light
  showMarkdown: true,
  fontScale: 1,                   // 0.875 / 1 / 1.125 / 1.25
  highContrast: false,
  reduceMotion: false,
};

export const DEFAULT_SESSION = {
  id: crypto.randomUUID(),
  createdAt: new Date().toISOString(),
  summary: '',
  messages: [
    {
      id: crypto.randomUUID(),
      role: 'system',
      content: 'ようこそ。左の「モデル」から WebLLM(WebGPU) または GGUF(Wllama) を読み込むとローカル推論を開始できます。\nショートカット: 設定 = Ctrl+, / Web検索 = Ctrl+K / 入力欄へ = Ctrl+L / Esc で停止',
      createdAt: new Date().toISOString(),
    },
  ],
  attachments: [],
};
