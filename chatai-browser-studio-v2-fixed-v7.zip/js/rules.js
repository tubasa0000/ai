// ============================================================
//  rules.js — モデレーション v2
//  方針:
//   1. 「挿入」「OD」「オーバードーズ」など曖昧語の誤検知をなくす
//   2. 単語境界 / 文脈 / 否定文を考慮した語彙ルール
//   3. ヒューリスティック→AI判定（任意）の二段構え
//   4. ストリーミング中の小チャンクでは判定しない（false-positive 防止）
// ============================================================

// --- 強シグナル（単独でほぼ確実に対象）-----------------------
const STRONG_SEXUAL = [
  /児童ポルノ/u,
  /近親相姦/u,
  /獣姦/u,
  /\bレイプ\b/u,
  /強姦/u,
  /chil[d]?\s*porn/iu,
];

const STRONG_VIOLENCE = [
  /(?:人|誰か|あいつ|彼|彼女)\s*を\s*(?:殺|頃)(?:す|そう|したい|してやる)/u,
  /自爆テロ/u,
  /爆弾の作り方/u,
  /毒(?:ガス|薬)の(?:作り方|製法|合成)/u,
  /銃の(?:作り方|自作|3D)/u,
  /無差別(?:殺人|テロ)/u,
];

// --- 弱シグナル（文脈次第。否定/メタ言及/ガード語があれば素通し）---
const WEAK_SEXUAL = [
  /性行為/u,
  /セックス/u,
  /ポルノ/u,
  /アダルト動画/u,
  /自慰/u,
  // 「挿入」は単独では誤検知が多いので、性的文脈にいるときだけ
  /(?:陰茎|ペニス|膣|肛門)\s*(?:に|へ|を)?\s*挿入/u,
];

const WEAK_VIOLENCE = [
  /(?:自分|わたし|私|俺)\s*を\s*殺(?:す|したい)/u,  // 自傷示唆
  /首吊り/u,
  /飛び降り(?:たい|る)/u,
];

// --- 専門領域（注意喚起のみ、ブロックはしない）-----------------
//   ★「OD」「オーバードーズ」の誤検知が多かったので、
//      ・OD は単語境界（前後が日本語 or 文頭/末）かつ大文字
//      ・「曲」「歌」「楽曲」「アルバム」「タイトル」「歌詞」が近くにある → 無視
//      ・否定文（「ODはしない」「OD防止」など）→ 無視
//      ・主語が一人称＋意志（「ODしたい/しよう」）の時のみ強警告
const MEDICAL_LIGHT = [
  /処方箋?/u,
  /用法用量/u,
  /抗生(?:物質|剤)/u,
  /心筋梗塞/u,
  /脳卒中/u,
  /薬物相互作用/u,
];

const OD_INTENT = /(?:^|[^A-Za-z])(?:OD|オーバードーズ)(?:[ 　]*(?:し(?:たい|よう|ます|た)|する|キメ|決め))/u;
const SELF_HARM_INTENT = /(?:死に(?:たい|たくて)|消えたい|楽になりたい).*?(?:薬|睡眠薬|市販薬)/u;

// 誤検知抑制: 文化的言及・否定・予防文脈
const BENIGN_CONTEXT = /(?:曲|歌|楽曲|アルバム|タイトル|歌詞|MV|アーティスト|バンド|映画|ドラマ|小説|フィクション|架空|歴史|統計|論文|授業|研究|防止|予防|対策|啓発|ニュース|報道|事例として|定義)/u;
const NEGATION_CONTEXT = /(?:しない|させない|やめ(?:て|よう|る)|禁止|ダメ|だめ|抑止|思いとどま)/u;

// ============================================================

function findHits(text, patterns) {
  const hits = [];
  for (const re of patterns) {
    if (re.test(text)) hits.push(re.source);
  }
  return hits;
}

const GREETINGS = /^(?:こんにちは|こんばんは|おはよう|よろしく|お疲れ様|はじめまして|バイバイ|さようなら|ありがと|助かる)(?:[！!。.\s]|$)/u;

function looksBenign(text) {
  // 挨拶や極端に短い肯定的なメッセージは常に benign (無害) とみなす
  if (text.length < 10 && GREETINGS.test(text)) return true;
  return BENIGN_CONTEXT.test(text) || NEGATION_CONTEXT.test(text);
}

export function buildPolicyPrompt(settings) {
  const rules = [];
  rules.push(
    settings.allowSexualContent
      ? '性的な話題は機械的に拒否しないが、未成年・非合意・違法描写は厳禁。露骨化や過度な扇情化は避ける。'
      : '性的な会話は基本的に避ける。文学・医療・教育・人権など正当な文脈は短く中立的に答えてよい。'
  );
  rules.push(
    settings.allowViolence
      ? '暴力表現は必要最小限とし、特定個人への危害計画・武器製造手順は出さない。'
      : '具体的な暴力・武器・違法薬物の製造手順は出さない。フィクションや報道は中立的に扱える。'
  );
  if (settings.strictMedical) {
    rules.push('医療・法律・金融・安全工学は一般情報として述べ、自己診断や断定は避け、必要に応じて専門家相談を勧める。');
  }
  rules.push('単語の文字列一致だけで話題を拒絶しない。曲名・作品名・歴史・統計・予防啓発などの正当な言及は普通に答えてよい。');
  return rules.join('\n');
}

// ----- ヒューリスティック判定（高速・誤検知少なめ）-----
export function moderateText(text, settings, { mode = 'final' } = {}) {
  const issues = [];
  const meta = { strong: [], weak: [], benign: false };

  // ストリーミング途中の極小チャンクは判定しない
  if (mode === 'stream' && text.length < 40) {
    return { blocked: false, issues, meta };
  }

  const benign = looksBenign(text);
  meta.benign = benign;

  // --- 強シグナル: 常時ブロック（benign でも例外なし）---
  if (!settings.allowSexualContent) {
    const hits = findHits(text, STRONG_SEXUAL);
    if (hits.length) {
      issues.push('sexual');
      meta.strong.push(...hits.map((h) => ({ kind: 'sexual', re: h })));
    }
  }
  if (!settings.allowViolence) {
    const hits = findHits(text, STRONG_VIOLENCE);
    if (hits.length) {
      issues.push('violence');
      meta.strong.push(...hits.map((h) => ({ kind: 'violence', re: h })));
    }
  }

  // --- 弱シグナル: benign 文脈なら無視 ---
  if (!benign) {
    if (!settings.allowSexualContent) {
      const hits = findHits(text, WEAK_SEXUAL);
      if (hits.length) {
        issues.push('sexual-soft');
        meta.weak.push(...hits.map((h) => ({ kind: 'sexual-soft', re: h })));
      }
    }
    if (!settings.allowViolence) {
      const hits = findHits(text, WEAK_VIOLENCE);
      if (hits.length) {
        issues.push('violence-soft');
        meta.weak.push(...hits.map((h) => ({ kind: 'violence-soft', re: h })));
      }
    }
  }

  // --- OD / 自傷: 意志表現がある時のみ強警告 ---
  if (settings.strictMedical) {
    if (OD_INTENT.test(text) && !benign) {
      issues.push('self-harm');
      meta.strong.push({ kind: 'self-harm', re: 'OD_INTENT' });
    }
    if (SELF_HARM_INTENT.test(text)) {
      issues.push('self-harm');
      meta.strong.push({ kind: 'self-harm', re: 'SELF_HARM_INTENT' });
    }
    if (findHits(text, MEDICAL_LIGHT).length) {
      issues.push('medical-caution');
    }
  }

  // --- 弱シグナルだけならソフト警告で、原則ブロックしない ---
  const blocked =
    issues.includes('sexual') ||
    issues.includes('violence') ||
    issues.includes('self-harm');

  return { blocked, issues, meta };
}

// ----- AI による二次判定（推奨）-----
//  ・現在ロード中のローカルLLMを使って "BLOCK|ALLOW|CAUTION" を返させる
//  ・低 temperature・短 max_tokens で安定化
//  ・タイムアウトや失敗時は heuristic 判定にフォールバック
export async function aiModerate({ text, settings, runOneShot, heuristic }) {
  if (!runOneShot) return heuristic;

  // 強ブロックは AI を呼ばずに即時 BLOCK
  if (heuristic.meta?.strong?.length) return heuristic;

  // 弱シグナルすら無い、または benign 文脈ならスキップ（高速化）
  const hasWeak = heuristic.meta?.weak?.length;
  const hasMedical = heuristic.issues?.includes('medical-caution');
  if (!hasWeak && !hasMedical) return heuristic;

  const policy = [
    settings.allowSexualContent ? '性的話題: 許可（ただし違法/未成年は禁止）' : '性的話題: 露骨な描写は不可（学術・芸術言及はOK）',
    settings.allowViolence ? '暴力描写: 必要最小限なら可' : '具体的な危害・武器製造手順は不可（フィクション言及はOK）',
    '自傷/自殺/OD: 本人の意志表明は要配慮（曲名・統計・予防啓発はOK）',
  ].join('\n');

  const prompt = [
    {
      role: 'system',
      content: [
        'あなたはAI回答の最終モデレーターです。',
        '次のテキストが下記ポリシーに違反するかを評価してください。',
        '出力は必ず JSON 1行のみ。例:',
        '{"verdict":"ALLOW|CAUTION|BLOCK","reason":"短い理由(日本語)"}',
        '・曲名・作品名・歴史・統計・予防啓発などの正当な言及は ALLOW。',
        '・単語一致だけで BLOCK しない。',
        '・本人の意志表明としての自傷/OD示唆は BLOCK。',
        '',
        '【ポリシー】',
        policy,
      ].join('\n'),
    },
    { role: 'user', content: `【評価対象】\n${text.slice(0, 1200)}` },
  ];

  try {
    const raw = await runOneShot(prompt, 80);
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) return heuristic;
    const obj = JSON.parse(m[0]);
    const verdict = String(obj.verdict || '').toUpperCase();
    if (verdict === 'BLOCK') {
      return {
        blocked: true,
        issues: [...new Set([...(heuristic.issues || []), 'ai-block'])],
        meta: { ...(heuristic.meta || {}), aiReason: obj.reason || '' },
      };
    }
    if (verdict === 'ALLOW') {
      // 弱シグナルしか無く AI が ALLOW と言った場合は通す
      return {
        blocked: false,
        issues: (heuristic.issues || []).filter((x) => x !== 'sexual-soft' && x !== 'violence-soft'),
        meta: { ...(heuristic.meta || {}), aiReason: obj.reason || '' },
      };
    }
    // CAUTION
    return {
      blocked: false,
      issues: [...new Set([...(heuristic.issues || []), 'caution'])],
      meta: { ...(heuristic.meta || {}), aiReason: obj.reason || '' },
    };
  } catch {
    return heuristic;
  }
}

export function renderModerationNotice(result) {
  if (!result?.issues?.length) return '';
  const labels = {
    sexual: '性的描写ルール',
    'sexual-soft': '性的話題に注意',
    violence: '危害/暴力ルール',
    'violence-soft': '暴力的表現に注意',
    'self-harm': '自傷/OD 示唆',
    'medical-caution': '医療領域は要確認',
    'ai-block': 'AI判定: 不適切',
    caution: 'AI判定: 要注意',
  };
  const text = result.issues.map((x) => labels[x] || x).join(' / ');
  return result.blocked
    ? `AIの回答はポリシー上ブロックされました（${text}）。`
    : `参考: ${text}`;
}
