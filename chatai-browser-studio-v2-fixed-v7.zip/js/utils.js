export function $(selector, root = document) {
  return root.querySelector(selector);
}

export function formatDateTime(value) {
  try {
    return new Date(value).toLocaleString('ja-JP', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
  } catch { return value; }
}

export function escapeHtml(input = '') {
  return String(input)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

export function estimateTokens(text = '') {
  return Math.max(1, Math.ceil(String(text).length / 3.2));
}

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

export function chunkText(text, chunkSize = 500, overlap = 60) {
  const normalized = String(text || '').trim();
  if (!normalized) return [];
  const chunks = [];
  let index = 0;
  while (index < normalized.length) {
    const end = Math.min(normalized.length, index + chunkSize);
    chunks.push(normalized.slice(index, end));
    if (end >= normalized.length) break;
    index = Math.max(end - overlap, index + 1);
  }
  return chunks;
}

export function cosineSimilarity(a = [], b = []) {
  if (!a.length || !b.length || a.length !== b.length) return 0;
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i += 1) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom ? dot / denom : 0;
}

export function stripHtml(html = '') {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return doc.body?.innerText?.replace(/\n{3,}/g, '\n\n').trim() || '';
}

export async function fileToObjectUrl(file) { return URL.createObjectURL(file); }

export async function fileToDataUrl(file) {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function downloadJson(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// 読み上げ用にマークダウン修飾記号・コードブロック・リンク URL を除去してプレーンテキスト化する。
//   - コードブロックは「（コードサンプルを省略）」に置換
//   - `インラインコード` は中身のみ
//   - **bold** / *italic* / __u__ / ~~s~~ は中身のみ
//   - 見出し #, ##, ### の先頭記号を除去
//   - リスト記号の先頭 - / * / 1. を除去
//   - [text](url) は text のみを残し URL を読み上げない
//   - 表や区切り線、> 引用記号を整理
export function stripMarkdownForSpeech(text = '') {
  let s = String(text);
  // コードブロックは読まず、短い合図に置換
  s = s.replace(/```[\s\S]*?```/g, ' コードブロックを省略します。 ');
  // インラインコード `xxx`
  s = s.replace(/`([^`\n]+)`/g, '$1');
  // リンク [text](url) → text
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1');
  // 画像 ![alt](url) → alt
  s = s.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '$1');
  // 見出しの # を削除
  s = s.replace(/^#{1,6}\s+/gm, '');
  // 強調 / 斜体 / 取り消し
  s = s.replace(/\*\*([^*]+)\*\*/g, '$1');
  s = s.replace(/__([^_]+)__/g, '$1');
  s = s.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '$1');
  s = s.replace(/(?<!_)_([^_\n]+)_(?!_)/g, '$1');
  s = s.replace(/~~([^~]+)~~/g, '$1');
  // 引用 > / リスト記号・番号付き
  s = s.replace(/^\s{0,3}>\s?/gm, '');
  s = s.replace(/^\s*[-*+]\s+/gm, '');
  s = s.replace(/^\s*\d+\.\s+/gm, '');
  // 水平線
  s = s.replace(/^[-*_]{3,}$/gm, ' ');
  // 表の区切り |---|
  s = s.replace(/^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/gm, ' ');
  // 表の | を読まずスペースに
  s = s.replace(/\s*\|\s*/g, ' ');
  // 生 URL (http/https) は「URL」と読み替え
  s = s.replace(/https?:\/\/\S+/g, 'URL');
  // HTML タグ除去
  s = s.replace(/<[^>]+>/g, ' ');
  // 連続空白を整理
  s = s.replace(/[ \t]{2,}/g, ' ');
  return s.trim();
}

// 文字列を「主に日本語 or 主に英語」にずんてん交互に分ける。
//   返り値: [{ lang: 'ja'|'en', text }]
//   記号・空白は直前のセグメントに伸ばす。
export function splitByLanguage(text = '') {
  const s = String(text);
  if (!s) return [];
  const isJp = (ch) => /[\u3040-\u309F\u30A0-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uFF66-\uFF9F\u3000-\u303F]/.test(ch);
  const isEn = (ch) => /[A-Za-z]/.test(ch);
  const segments = [];
  let cur = { lang: null, text: '' };
  for (const ch of s) {
    let lang = null;
    if (isJp(ch)) lang = 'ja';
    else if (isEn(ch)) lang = 'en';
    if (lang && cur.lang && lang !== cur.lang) {
      segments.push(cur);
      cur = { lang, text: ch };
    } else {
      if (lang) cur.lang = cur.lang || lang;
      cur.text += ch;
    }
  }
  if (cur.text.trim()) segments.push(cur);
  // 言語未確定のスタート是補をデフォルト ja に
  return segments
    .filter((seg) => seg.text.trim())
    .map((seg) => ({ lang: seg.lang || 'ja', text: seg.text }));
}

export function splitIntoSpeakableSentences(text = '') {
  return String(text)
    .split(/(?<=[。！？!?\n])/)
    .map((part) => part.trim())
    .filter(Boolean);
}

export async function safeFetchText(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Fetch failed: ${response.status}`);
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('text/html')) return stripHtml(await response.text());
  return await response.text();
}

export function createId(prefix = 'id') {
  return `${prefix}-${crypto.randomUUID()}`;
}

export function setBadge(el, label, tone = '') {
  if (!el) return;
  el.textContent = label;
  el.className = `badge ${tone}`.trim();
}

// ---------------- Markdown (簡易・安全) ----------------
//   既存の escapeHtml 経由で XSS を防ぐ。code/inline-code/bold/italic/link/list/heading のみ。
export function renderMarkdown(src = '') {
  let s = escapeHtml(src);
  // コードフェンス
  s = s.replace(/```([a-zA-Z0-9_+\-]*)\n([\s\S]*?)```/g, (_, lang, code) =>
    `<pre class="md-code" data-lang="${escapeHtml(lang)}"><code>${code}</code></pre>`);
  // インラインコード
  s = s.replace(/`([^`\n]+)`/g, '<code class="md-inline">$1</code>');
  // 見出し
  s = s.replace(/^### (.*)$/gm, '<h4 class="md-h">$1</h4>');
  s = s.replace(/^## (.*)$/gm, '<h3 class="md-h">$1</h3>');
  s = s.replace(/^# (.*)$/gm, '<h2 class="md-h">$1</h2>');
  // bold / italic
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
  // リンク
  s = s.replace(/\[([^\]]+)\]\((https?:[^\s)]+)\)/g,
    '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  // 箇条書き
  s = s.replace(/(^|\n)([-*])\s+(.+)/g, (_, p, _b, t) => `${p}<li class="md-li">${t}</li>`);
  s = s.replace(/(<li class="md-li">[\s\S]+?<\/li>)(?!\n<li)/g, '<ul class="md-ul">$1</ul>');
  // 改行
  s = s.replace(/\n{2,}/g, '<br><br>').replace(/\n/g, '<br>');
  return s;
}

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch { return false; }
}
