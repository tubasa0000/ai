// ============================================================
//  mcp.js — 実験的MCPクライアント (JSON-RPC over HTTP/SSE)
//  注: HTTP MCP サーバー前提（SSEは簡易対応）。CORS は相手任せ。
// ============================================================

export class MCPClient {
  constructor(endpoint = '') {
    this.endpoint = endpoint;
    this.tools = [];
  }

  setEndpoint(endpoint) {
    this.endpoint = (endpoint || '').trim();
  }

  async _call(method, params = {}) {
    if (!this.endpoint) throw new Error('MCP endpoint is empty.');
    const response = await fetch(this.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: crypto.randomUUID(), method, params }),
    });
    if (!response.ok) throw new Error(`MCP request failed: ${response.status}`);
    const data = await response.json();
    if (data.error) throw new Error(data.error.message || 'MCP error');
    return data.result;
  }

  async connect() {
    try {
      await this._call('initialize', {
        protocolVersion: '2025-03-26',
        clientInfo: { name: 'chatai-browser-studio', version: '2.0.0' },
        capabilities: {},
      });
    } catch {
      // 一部のサーバーは initialize 不要
    }
    const result = await this._call('tools/list', {});
    this.tools = result?.tools || [];
    return this.tools;
  }

  async invokeTool(name, args = {}) {
    return await this._call('tools/call', { name, arguments: args });
  }

  toolList() {
    return (this.tools || []).map((t) => ({
      name: t.name,
      description: t.description || '',
      inputSchema: t.inputSchema,
      origin: 'mcp',
      available: true,
    }));
  }

  formatToolList() {
    if (!this.tools?.length) return '未接続';
    return this.tools
      .map((tool) => `• ${tool.name}${tool.description ? ` — ${tool.description}` : ''}`)
      .join('\n');
  }
}

// ============================================================
//  自動ツール呼び出しエンジン
//  ・モデルが [TOOL_CALL]{"name":"...","arguments":{...}}[/TOOL_CALL] を吐いたら拾う
//  ・対応する Tool Provider に転送して結果を取得
//  ・結果を会話履歴に "tool" / "system" として注入し、再生成
// ============================================================

export const TOOL_CALL_RE = /\[TOOL_CALL\]\s*([\s\S]*?)\s*\[\/TOOL_CALL\]/i;

export function parseToolCall(text) {
  if (!text) return null;
  const m = text.match(TOOL_CALL_RE);
  if (!m) return null;
  try {
    const obj = JSON.parse(m[1]);
    if (!obj?.name) return null;
    return { name: String(obj.name), arguments: obj.arguments || obj.args || {}, raw: m[0] };
  } catch {
    return null;
  }
}

export function buildToolGuide(allTools, { autoMode = true } = {}) {
  if (!allTools?.length) return '';
  const list = allTools
    .filter((t) => t.available !== false)
    .map((t) => {
      const schema = t.inputSchema ? `  入力: ${JSON.stringify(t.inputSchema).slice(0, 240)}` : '';
      return `- ${t.name} (${t.origin})${t.description ? ` — ${t.description}` : ''}\n${schema}`;
    })
    .join('\n');
  const fmt = [
    '【利用可能ツール】',
    list,
    '',
    autoMode
      ? '必要な時のみ、次の形式で呼び出してください。1回の発話で 1 ツールだけ。'
      : '※自動呼出はオフ。ツールを案内する程度に留めてください。',
    '[TOOL_CALL]{"name":"<tool>","arguments":{...}}[/TOOL_CALL]',
    '結果はシステムから "tool_result" として戻ります。受け取ったら、それを踏まえて最終回答してください。',
    '不要な時はツールを呼ばず、直接答えてください。',
  ].join('\n');
  return fmt;
}
