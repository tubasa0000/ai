// ============================================================
//  media.js — 音声 (ASR / TTS) と画像理解
//  画像理解の強化:
//   ・モデルを動的に切替 (VITGPT2 / BLIP / Florence-2 系 ONNX)
//   ・大きい画像は自動リサイズ
//   ・キャプションを後段 LLM に渡してより詳しい説明に書き換え（任意）
// ============================================================

import { ASR_MODEL, CDN, IMAGE_CAPTION_MODELS, DEFAULT_IMAGE_CAPTION_MODEL } from './config.js';
import { splitIntoSpeakableSentences, stripMarkdownForSpeech, splitByLanguage } from './utils.js';

let transformersModulePromise;
async function getTransformers() {
  if (!transformersModulePromise) {
    transformersModulePromise = (async () => {
      const mod = await import(CDN.transformers);
      // CSP/COEP 下で cross-origin Worker が弾かれると SecurityError になるため、
      // ONNX Runtime のプロキシ Worker を無効化して main thread で走らせる。
      try {
        const env = mod.env;
        if (env) {
          env.allowLocalModels = false;
          env.useBrowserCache = true;
          if (env.backends?.onnx?.wasm) {
            env.backends.onnx.wasm.proxy = false;       // ← Worker 作らない
            env.backends.onnx.wasm.numThreads = 1;       // SharedArrayBuffer 依存も避ける
          }
        }
      } catch (e) {
        console.warn('transformers env tweak failed:', e);
      }
      return mod;
    })();
  }
  return await transformersModulePromise;
}

// ---------------- 音声 ----------------
export class SpeechController {
  constructor(settingsProvider) {
    this.settingsProvider = settingsProvider;
    this.recognition = null;
    this.speakingEnabled = true;
    this.voiceList = [];
    this.queue = [];
    this.processing = false;
    this.captureStream = null;
    this.mediaRecorder = null;
    this.recordedChunks = [];
  }

  getVoices() {
    this.voiceList = window.speechSynthesis?.getVoices?.() || [];
    return this.voiceList;
  }

  startBrowserRecognition(onText) {
    const API = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!API) throw new Error('このブラウザは SpeechRecognition に対応していません。');
    this.recognition = new API();
    this.recognition.lang = 'ja-JP';
    this.recognition.interimResults = true;
    this.recognition.continuous = true;
    this.recognition.onresult = (event) => {
      const text = Array.from(event.results)
        .map((result) => result[0]?.transcript || '')
        .join('');
      onText(text);
    };
    this.recognition.onerror = () => {};
    this.recognition.start();
  }

  stopBrowserRecognition() {
    this.recognition?.stop?.();
  }

  async startRecorder() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.captureStream = stream;
    this.recordedChunks = [];
    this.mediaRecorder = new MediaRecorder(stream);
    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data?.size) this.recordedChunks.push(event.data);
    };
    this.mediaRecorder.start();
  }

  async stopRecorderAndTranscribe() {
    if (!this.mediaRecorder) throw new Error('Recorder is not active.');
    await new Promise((resolve) => {
      this.mediaRecorder.onstop = resolve;
      this.mediaRecorder.stop();
    });
    this.captureStream?.getTracks?.().forEach((track) => track.stop());
    const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
    const { pipeline } = await getTransformers();
    let transcriber;
    const settings = this.settingsProvider();
    const useGpu = navigator.gpu && !settings.disableWebGpu;
    try {
      transcriber = await pipeline('automatic-speech-recognition', ASR_MODEL, {
        device: useGpu ? 'webgpu' : 'wasm',
      });
    } catch (e) {
      console.warn('ASR WebGPU failed, falling back to wasm:', e);
      transcriber = await pipeline('automatic-speech-recognition', ASR_MODEL, {
        device: 'wasm',
      });
    }
    const result = await transcriber(URL.createObjectURL(blob), {
      language: 'japanese',
      task: 'transcribe',
    });
    return result.text || '';
  }

  stopAllSpeech() {
    window.speechSynthesis?.cancel?.();
    this.queue = [];
    this.processing = false;
  }

  enqueueStreamingSpeech(text, moderationFn) {
    if (!this.speakingEnabled || !text?.trim()) return;
    // マークダウン記号を読み上げさせない
    const plain = stripMarkdownForSpeech(text);
    if (!plain.trim()) return;
    const pieces = splitIntoSpeakableSentences(plain);
    pieces.forEach((piece) => {
      if (!piece) return;
      if (moderationFn && moderationFn(piece)) return;
      // 文ごとに言語を判定してja/enセグメントに分割してキューイング
      const segments = splitByLanguage(piece);
      if (!segments.length) {
        this.queue.push({ lang: 'ja', text: piece });
      } else {
        segments.forEach((seg) => {
          if (seg.text.trim()) this.queue.push(seg);
        });
      }
    });
    this.processQueue();
  }

  async processQueue() {
    if (this.processing || !this.queue.length) return;
    this.processing = true;
    while (this.queue.length && this.speakingEnabled) {
      const part = this.queue.shift();
      // 下位互換: 文字列がキューに残っていた場合は ja 扱い
      const seg = typeof part === 'string' ? { lang: 'ja', text: part } : part;
      await this.speak(seg.text, seg.lang);
    }
    this.processing = false;
  }

  _pickVoiceFor(lang, settings) {
    const voices = this.getVoices();
    // ユーザーが明示選択している声があり、その言語タグが指定言語と一致するときだけ使う。
    const explicit = settings.ttsVoiceURI && voices.find((v) => v.voiceURI === settings.ttsVoiceURI);
    if (explicit) {
      const matchesUser = lang === 'ja'
        ? /^ja(\b|-|_)/i.test(explicit.lang || '')
        : /^en(\b|-|_)/i.test(explicit.lang || '');
      if (matchesUser) return explicit;
    }
    // 言語一致するボイスを探す
    const langPrefix = lang === 'ja' ? /^ja(\b|-|_)/i : /^en(\b|-|_)/i;
    const preferLocal = voices.filter((v) => langPrefix.test(v.lang || ''));
    if (preferLocal.length) {
      // Microsoft / Google / Apple の言語コート を優先してもいいが、シンプルに先頭
      return preferLocal[0];
    }
    // フォールバック: explicit もしくは本当に何もない
    return explicit || null;
  }

  speak(text, lang = 'ja') {
    return new Promise((resolve) => {
      const settings = this.settingsProvider();
      const utterance = new SpeechSynthesisUtterance(text);
      const voice = this._pickVoiceFor(lang, settings);
      if (voice) utterance.voice = voice;
      utterance.lang = voice?.lang || (lang === 'en' ? 'en-US' : 'ja-JP');
      utterance.rate = Number(settings.ttsRate || 1);
      utterance.pitch = Number(settings.ttsPitch || 1);
      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();
      window.speechSynthesis.speak(utterance);
    });
  }
}

// ---------------- 画像 ----------------
async function dataUrlToResizedDataUrl(dataUrl, maxSide = 768) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      const scale = Math.min(1, maxSide / Math.max(width, height));
      width = Math.round(width * scale);
      height = Math.round(height * scale);
      const c = document.createElement('canvas');
      c.width = width;
      c.height = height;
      c.getContext('2d').drawImage(img, 0, 0, width, height);
      resolve(c.toDataURL('image/jpeg', 0.92));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export class ImageController {
  constructor(settingsProvider) {
    this.settingsProvider = settingsProvider;
    this.stream = null;
    this._captioner = null;
    this._captionerKey = '';
  }

  async startCamera(videoEl) {
    this.stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment' },
      audio: false,
    });
    videoEl.srcObject = this.stream;
    await videoEl.play();
  }

  stopCamera(videoEl) {
    this.stream?.getTracks?.().forEach((track) => track.stop());
    this.stream = null;
    if (videoEl) videoEl.srcObject = null;
  }

  captureFromVideo(videoEl) {
    const canvas = document.createElement('canvas');
    canvas.width = videoEl.videoWidth || 1280;
    canvas.height = videoEl.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.92);
  }

  async _ensureCaptioner(modelId) {
    const key = modelId || DEFAULT_IMAGE_CAPTION_MODEL;
    if (this._captioner && this._captionerKey === key) return this._captioner;
    const { pipeline } = await getTransformers();
    const entry = IMAGE_CAPTION_MODELS.find((m) => m.id === key) || IMAGE_CAPTION_MODELS[0];
    const settings = this.settingsProvider ? this.settingsProvider() : { disableWebGpu: false };
    const useGpu = navigator.gpu && !settings.disableWebGpu;
    try {
      this._captioner = await pipeline(entry.task || 'image-to-text', entry.id, {
        device: useGpu ? 'webgpu' : 'wasm',
      });
    } catch (e) {
      console.warn('Image captioning WebGPU failed, falling back to wasm:', e);
      this._captioner = await pipeline(entry.task || 'image-to-text', entry.id, {
        device: 'wasm',
      });
    }
    this._captionerKey = key;
    return this._captioner;
  }

  async describeImage(imageUrl, { modelId, refine } = {}) {
    const resized = await dataUrlToResizedDataUrl(imageUrl, 768);
    const captioner = await this._ensureCaptioner(modelId);
    const result = await captioner(resized);
    let caption = Array.isArray(result)
      ? result[0]?.generated_text || ''
      : result?.generated_text || '';

    // 任意: LLM で日本語のリッチな説明に書き換え
    if (refine && caption) {
      try {
        caption = await refine(caption);
      } catch { /* 失敗時は素のキャプション */ }
    }
    return caption;
  }
}
