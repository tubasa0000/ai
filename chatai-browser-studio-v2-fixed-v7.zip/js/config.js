// ============================================================
//  config.js — 定数・既定モデル
// ============================================================

export const APP_NAME = 'ChatAI Browser Studio';
export const APP_VERSION = '2.0.0';

// esm.sh の ?bundle フラグは Node 依存の polyfill (createRequire 等) を混ぜてしまい
// ブラウザで ReferenceError になるため、standalone ESM ビルドを参照する。
//
// transformers.js は @huggingface/transformers の内部で Worker を起動するため、
// COEP=require-corp の同一オリジン下では cross-origin Worker が SecurityError を吐く。
// → server.mjs の /vendor/transformers ルートでプロキシ配信し、同一オリジンに見せる。
// 直接 CDN を叩きたい場合は USE_DIRECT_CDN を true にする。
const USE_DIRECT_CDN = false;
export const CDN = {
  transformers: USE_DIRECT_CDN
    ? 'https://esm.sh/@huggingface/transformers@3.0.2'
    : './vendor/transformers/index.mjs',
  webllm:       'https://esm.run/@mlc-ai/web-llm',
  wllama:       'https://cdn.jsdelivr.net/npm/@wllama/wllama@2.2.1/esm/index.js',
  wllamaWasm:   'https://cdn.jsdelivr.net/npm/@wllama/wllama@2.2.1/esm/wasm-from-cdn.js',
};

// llama.cpp (Wllama) がサポートする主要アーキテクチャ。
// 事前判定で未対応モデルを弾くために使う (大文字小文字無視)。
// 参考: https://github.com/ggerganov/llama.cpp の src/llama-arch.cpp
export const WLLAMA_SUPPORTED_ARCHS = new Set([
  'llama','qwen','qwen2','qwen2moe','qwen2vl','qwen3','qwen3moe',
  'phi','phi2','phi3','phimoe',
  'gemma','gemma2','gemma3',
  'mistral','mixtral',
  'gpt2','gptj','gptneox','starcoder','starcoder2','codeshell',
  'falcon','baichuan','stablelm','internlm2','minicpm','minicpm3',
  'command-r','olmo','olmoe','openelm','arctic','deepseek','deepseek2',
  'chatglm','xverse','orion','plamo','granite','granitemoe','rwkv6',
  'mpt','bloom','refact','bert','jais','nemotron','exaone','t5','t5encoder',
]);

// WebLLM プリセット (動作確認用に複数追加)
export const PRESET_WEBLLM_MODELS = [
  'Qwen2.5-0.5B-Instruct-q4f16_1-MLC',
  'Qwen2.5-1.5B-Instruct-q4f16_1-MLC',
  'Qwen2.5-3B-Instruct-q4f16_1-MLC',
  'Llama-3.2-1B-Instruct-q4f32_1-MLC',
  'Llama-3.2-3B-Instruct-q4f16_1-MLC',
  'Phi-3.5-mini-instruct-q4f16_1-MLC',
  'gemma-2-2b-it-q4f16_1-MLC',
  'SmolLM2-1.7B-Instruct-q4f16_1-MLC',
];

// GGUF プリセット (Wllama 用)
//   ★ Wllama (llama.cpp WASM) が対応しているアーキのみ既定候補に並べる。
//      LFM2 / LFM2.5 (LiquidAI) は llama.cpp が "lfm2" アーキ未対応のため除外。
//      llm-jp-3 (gpt-neox 系) は wllama 対応。
export const PRESET_GGUF_REPOS = [
  { repo: 'Qwen/Qwen2.5-1.5B-Instruct-GGUF',     file: 'qwen2.5-1.5b-instruct-q4_k_m.gguf',  label: 'Qwen2.5 1.5B Instruct (Q4_K_M) ★既定' },
  { repo: 'Qwen/Qwen2.5-3B-Instruct-GGUF',       file: 'qwen2.5-3b-instruct-q4_k_m.gguf',    label: 'Qwen2.5 3B Instruct (Q4_K_M)' },
  { repo: 'bartowski/Llama-3.2-1B-Instruct-GGUF', file: 'Llama-3.2-1B-Instruct-Q4_K_M.gguf', label: 'Llama 3.2 1B Instruct (Q4_K_M)' },
  { repo: 'bartowski/Llama-3.2-3B-Instruct-GGUF', file: 'Llama-3.2-3B-Instruct-Q4_K_M.gguf', label: 'Llama 3.2 3B Instruct (Q4_K_M)' },
  { repo: 'bartowski/gemma-2-2b-it-GGUF',         file: 'gemma-2-2b-it-Q4_K_M.gguf',         label: 'Gemma2 2B IT (Q4_K_M)' },
  { repo: 'mmnga/llm-jp-3-1.8b-instruct-gguf',    file: 'llm-jp-3-1.8b-instruct-Q4_K_M.gguf', label: 'llm-jp-3 1.8B JP (Q4_K_M)' },
  // 参考: LFM2 系は wllama (llama.cpp) では未対応アーキのため非推奨
  // { repo: 'LiquidAI/LFM2.5-1.2B-JP-202606-GGUF', file: 'LFM2.5-1.2B-JP-202606-Q4_K_M.gguf', label: 'LFM2.5 1.2B JP (※wllama未対応)' },
];

export const DEFAULT_GGUF_REPO = PRESET_GGUF_REPOS[0].repo;
export const DEFAULT_GGUF_FILE = PRESET_GGUF_REPOS[0].file;

export const EMBEDDING_MODEL = 'mixedbread-ai/mxbai-embed-xsmall-v1';
export const ASR_MODEL       = 'onnx-community/whisper-tiny';

// 画像キャプション: 任意で切替可能。Florence-2 は英語キャプション精度が高い
export const IMAGE_CAPTION_MODELS = [
  { id: 'Xenova/vit-gpt2-image-captioning', label: 'ViT-GPT2 (軽量・英)', task: 'image-to-text' },
  { id: 'Xenova/blip-image-captioning-base', label: 'BLIP base (英)', task: 'image-to-text' },
  { id: 'onnx-community/Florence-2-base-ft', label: 'Florence-2 base (高品質・英)', task: 'image-to-text' },
];
export const DEFAULT_IMAGE_CAPTION_MODEL = IMAGE_CAPTION_MODELS[0].id;

export const STORAGE_KEYS = {
  settings:  'chatai-browser-settings-v2',
  session:   'chatai-browser-session-v2',
  knowledge: 'chatai-browser-knowledge-v2',
  mcp:       'chatai-browser-mcp-v2',
};

export const MAX_ATTACHMENT_SIZE_MB = 20;
export const NODE_API_BASE = ''; // 同一オリジン
