// ============================================================
//  ChatAI Browser Studio — app.js (v7)
//  改善:
//   - ローディングオーバーレイ / タイピングインジケータ
//   - グローバル ショートカットキー
//   - 履歴 API (popstate) で戻るボタンによるダイアログ閉じ対応
//   - フォントスケール / 高コントラスト / アニメーション抑制
//   - import / clearChat 等で confirm の dialog 化 / aria 同期
//   - サイドバーの aria-expanded 同期 / フォーカストラップ簡易
// ============================================================
import { APP_NAME, APP_VERSION, DEFAULT_GGUF_FILE, IMAGE_CAPTION_MODELS, PRESET_GGUF_REPOS, PRESET_WEBLLM_MODELS } from './config.js';
import { DEFAULT_SETTINGS } from './defaults.js';
import { AdapterManager } from './adapters.js';
import { ImageController, SpeechController } from './media.js';
import { MemoryManager } from './memory.js';
import { MCPClient, buildToolGuide, parseToolCall } from './mcp.js';
import { NodeToolClient } from './node-tools.js';
import { aiModerate, buildPolicyPrompt, moderateText, renderModerationNotice } from './rules.js';
import {
  loadKnowledgeBase, loadMcpState, loadSession, loadSettings, normalizeSession,
  saveKnowledgeBase, saveMcpState, saveSession, saveSettings,
} from './storage.js';
import {
  $, copyText, createId, downloadJson, escapeHtml, estimateTokens,
  formatDateTime, renderMarkdown, safeFetchText, setBadge,
} from './utils.js';

const els = {
  providerSelect: $('#providerSelect'),
  wllamaFields: $('#wllamaFields'),
  webllmFields: $('#webllmFields'),
  ggufPresetSelect: $('#ggufPresetSelect'),
  hfRepoInput: $('#hfRepoInput'),
  hfFileSelect: $('#hfFileSelect'),
  ggufUploadInput: $('#ggufUploadInput'),
  webllmModelSelect: $('#webllmModelSelect'),
  customWebllmRecord: $('#customWebllmRecord'),
  temperatureInput: $('#temperatureInput'),
  maxTokensInput: $('#maxTokensInput'),
  topPInput: $('#topPInput'),
  contextBudgetInput: $('#contextBudgetInput'),
  modelStatus: $('#modelStatus'),
  loadModelBtn: $('#loadModelBtn'),
  stopGenerationBtn: $('#stopGenerationBtn'),
  clearChatBtn: $('#clearChatBtn'),
  refreshFilesBtn: $('#refreshFilesBtn'),
  messageInput: $('#messageInput'),
  sendBtn: $('#sendBtn'),
  chatMessages: $('#chatMessages'),
  composerStatus: $('#composerStatus'),
  knowledgeInput: $('#knowledgeInput'),
  addKnowledgeBtn: $('#addKnowledgeBtn'),
  rebuildEmbeddingsBtn: $('#rebuildEmbeddingsBtn'),
  summarizeNowBtn: $('#summarizeNowBtn'),
  ragUrlInput: $('#ragUrlInput'),
  fetchUrlBtn: $('#fetchUrlBtn'),
  ragStatus: $('#ragStatus'),
  exportBtn: $('#exportBtn'),
  importInput: $('#importInput'),
  toggleSettingsBtn: $('#toggleSettingsBtn'),
  settingsDialog: $('#settingsDialog'),
  systemPromptInput: $('#systemPromptInput'),
  conversationRulesInput: $('#conversationRulesInput'),
  allowSexualContentCheckbox: $('#allowSexualContentCheckbox'),
  allowViolenceCheckbox: $('#allowViolenceCheckbox'),
  strictMedicalCheckbox: $('#strictMedicalCheckbox'),
  aiModerationCheckbox: $('#aiModerationCheckbox'),
  useNodeModerationCheckbox: $('#useNodeModerationCheckbox'),
  blockUnsafeTtsCheckbox: $('#blockUnsafeTtsCheckbox'),
  streamTtsCheckbox: $('#streamTtsCheckbox'),
  maxTurnsInput: $('#maxTurnsInput'),
  compressionStrategySelect: $('#compressionStrategySelect'),
  retrievalKInput: $('#retrievalKInput'),
  speechInputEngineSelect: $('#speechInputEngineSelect'),
  ttsEngineSelect: $('#ttsEngineSelect'),
  ttsVoiceSelect: $('#ttsVoiceSelect'),
  ttsRateInput: $('#ttsRateInput'),
  ttsPitchInput: $('#ttsPitchInput'),
  micBtn: $('#micBtn'),
  cameraBtn: $('#cameraBtn'),
  imageInput: $('#imageInput'),
  describeImageBtn: $('#describeImageBtn'),
  attachmentPreview: $('#attachmentPreview'),
  cameraPreview: $('#cameraPreview'),
  ttsToggleBtn: $('#ttsToggleBtn'),
  webSearchBtn: $('#webSearchBtn'),
  forceSearchToggle: $('#forceSearchToggle'),
  gpuBadge: $('#gpuBadge'),
  micBadge: $('#micBadge'),
  cameraBadge: $('#cameraBadge'),
  nodeBadge: $('#nodeBadge'),
  mcpEndpointInput: $('#mcpEndpointInput'),
  mcpEnabledCheckbox: $('#mcpEnabledCheckbox'),
  connectMcpBtn: $('#connectMcpBtn'),
  mcpToolsList: $('#mcpToolsList'),
  useNodeToolsCheckbox: $('#useNodeToolsCheckbox'),
  autoToolCallsCheckbox: $('#autoToolCallsCheckbox'),
  toolCallRoundsInput: $('#toolCallRoundsInput'),
  imageCaptionModelSelect: $('#imageCaptionModelSelect'),
  refineCaptionWithLLMCheckbox: $('#refineCaptionWithLLMCheckbox'),
  disableWebGpuCheckbox: $('#disableWebGpuCheckbox'),
  themeSelect: $('#themeSelect'),
  showMarkdownCheckbox: $('#showMarkdownCheckbox'),
  fontScaleSelect: $('#fontScaleSelect'),
  highContrastCheckbox: $('#highContrastCheckbox'),
  reduceMotionCheckbox: $('#reduceMotionCheckbox'),
  openSidebarBtn: $('#openSidebarBtn'),
  closeSidebarBtn: $('#closeSidebarBtn'),
  themeToggleBtn: $('#themeToggleBtn'),
  sidebar: $('#sidebar'),
  sidebarBackdrop: $('#sidebarBackdrop'),
  toast: $('#toast'),
  busyOverlay: $('#busyOverlay'),
  busyText: $('#busyText'),
  busyCancelBtn: $('#busyCancelBtn'),
};

const state = {
  settings: { ...DEFAULT_SETTINGS, ...loadSettings() },
  session: loadSession(),
  knowledgeBase: loadKnowledgeBase(),
  mcpState: loadMcpState(),
  adapterManager: new AdapterManager(),
  pendingAttachment: null,
  generating: false,
  micActive: false,
  cameraActive: false,
  toolsCatalog: [],
  sidebarOpen: false,
  settingsOpen: false,
};

const memory = new MemoryManager(
  () => state.knowledgeBase,
  (v) => { state.knowledgeBase = v; saveKnowledgeBase(v); },
  () => state.settings,
);
const speech = new SpeechController(() => state.settings);
const images = new ImageController(() => state.settings);
const mcp = new MCPClient(state.mcpState.endpoint || state.settings.mcpEndpoint || '');
const nodeTools = new NodeToolClient();

// ----------------- 共通ヘルパ -----------------
function saveAll() {
  saveSettings(state.settings);
  saveSession(state.session);
  saveKnowledgeBase(state.knowledgeBase);
  saveMcpState(state.mcpState);
}

function showToast(message, tone = '') {
  els.toast.textContent = message;
  els.toast.className = `toast show ${tone}`.trim();
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => { els.toast.classList.remove('show'); }, 2800);
}

function showBusy(text = '読み込み中…', { cancelable = false, onCancel = null } = {}) {
  els.busyText.textContent = text;
  els.busyOverlay.classList.remove('hidden');
  if (cancelable && onCancel) {
    els.busyCancelBtn.hidden = false;
    els.busyCancelBtn.onclick = () => { onCancel(); hideBusy(); };
  } else {
    els.busyCancelBtn.hidden = true;
    els.busyCancelBtn.onclick = null;
  }
}
function updateBusy(text) { els.busyText.textContent = text; }
function hideBusy() { els.busyOverlay.classList.add('hidden'); }

function applyTheme() {
  const t = state.settings.theme || 'auto';
  document.body.setAttribute('data-theme', t);
}
function applyA11y() {
  document.documentElement.style.setProperty('--font-scale', String(state.settings.fontScale ?? 1));
  document.body.setAttribute('data-contrast', state.settings.highContrast ? 'high' : 'normal');
  document.body.setAttribute('data-reduce-motion', state.settings.reduceMotion ? 'true' : 'false');
}

function setSidebar(open) {
  state.sidebarOpen = open;
  els.sidebar.classList.toggle('open', open);
  els.sidebarBackdrop.classList.toggle('show', open);
  els.openSidebarBtn?.setAttribute('aria-expanded', String(open));
  if (open) {
    // フォーカスをサイドバー内に移す (a11y)
    setTimeout(() => els.sidebar.focus?.(), 0);
  }
}

function setComposerStatus(text) { els.composerStatus.textContent = text; }
function setModelStatus(text)    { els.modelStatus.textContent = text; }

// ----------------- UI 同期 -----------------
function updateProviderVisibility() {
  const isWebLLM = els.providerSelect.value === 'webllm';
  els.webllmFields.classList.toggle('hidden', !isWebLLM);
  els.wllamaFields.classList.toggle('hidden', isWebLLM);
}

async function updateCapabilityBadges() {
  const gpuOk = navigator.gpu && !state.settings.disableWebGpu;
  setBadge(els.gpuBadge, gpuOk ? 'WebGPU 可' : (state.settings.disableWebGpu ? 'WebGPU 無効設定' : 'WebGPU なし'), gpuOk ? 'good' : 'warn');
  setBadge(els.micBadge, navigator.mediaDevices?.getUserMedia ? 'Mic 可' : 'Mic なし', navigator.mediaDevices?.getUserMedia ? 'good' : 'bad');
  setBadge(els.cameraBadge, navigator.mediaDevices?.getUserMedia ? 'Camera 可' : 'Camera なし', navigator.mediaDevices?.getUserMedia ? 'good' : 'bad');
  const tools = await nodeTools.probe();
  if (nodeTools.available) {
    setBadge(els.nodeBadge, `Node ツール ${tools.length}`, 'good');
  } else {
    setBadge(els.nodeBadge, 'Node なし', 'warn');
  }
}

function populateWebllmModels() {
  els.webllmModelSelect.innerHTML = '';
  PRESET_WEBLLM_MODELS.forEach((m) => {
    const o = document.createElement('option');
    o.value = m; o.textContent = m;
    els.webllmModelSelect.appendChild(o);
  });
}

function populateGgufPresets() {
  els.ggufPresetSelect.innerHTML = '<option value="">— カスタム —</option>';
  PRESET_GGUF_REPOS.forEach((p) => {
    const o = document.createElement('option');
    o.value = JSON.stringify({ repo: p.repo, file: p.file });
    o.textContent = p.label;
    els.ggufPresetSelect.appendChild(o);
  });
}

function populateCaptionModels() {
  els.imageCaptionModelSelect.innerHTML = '';
  IMAGE_CAPTION_MODELS.forEach((m) => {
    const o = document.createElement('option');
    o.value = m.id; o.textContent = m.label;
    els.imageCaptionModelSelect.appendChild(o);
  });
}

function populateVoices() {
  const voices = speech.getVoices();
  els.ttsVoiceSelect.innerHTML = '<option value="">自動</option>';
  voices.forEach((v) => {
    const o = document.createElement('option');
    o.value = v.voiceURI; o.textContent = `${v.name} (${v.lang})`;
    els.ttsVoiceSelect.appendChild(o);
  });
  if (state.settings.ttsVoiceURI) els.ttsVoiceSelect.value = state.settings.ttsVoiceURI;
}

function applySettingsToUI() {
  const s = state.settings;
  els.providerSelect.value = s.provider;
  els.hfRepoInput.value = s.hfRepo;
  els.customWebllmRecord.value = s.customWebllmRecord || '';
  els.webllmModelSelect.value = s.webllmModel;
  els.temperatureInput.value = s.temperature;
  els.maxTokensInput.value = s.maxTokens;
  els.topPInput.value = s.topP;
  els.contextBudgetInput.value = s.contextBudget;
  els.systemPromptInput.value = s.systemPrompt;
  els.conversationRulesInput.value = s.conversationRules;
  els.allowSexualContentCheckbox.checked = s.allowSexualContent;
  els.allowViolenceCheckbox.checked = s.allowViolence;
  els.strictMedicalCheckbox.checked = s.strictMedical;
  els.aiModerationCheckbox.checked = s.aiModeration;
  els.useNodeModerationCheckbox.checked = s.useNodeModeration;
  els.blockUnsafeTtsCheckbox.checked = s.blockUnsafeTts;
  els.streamTtsCheckbox.checked = s.streamTts;
  els.maxTurnsInput.value = s.maxTurns;
  els.compressionStrategySelect.value = s.compressionStrategy;
  els.retrievalKInput.value = s.retrievalK;
  els.speechInputEngineSelect.value = s.speechInputEngine;
  els.ttsEngineSelect.value = s.ttsEngine;
  els.ttsRateInput.value = s.ttsRate;
  els.ttsPitchInput.value = s.ttsPitch;
  els.mcpEndpointInput.value = s.mcpEndpoint || state.mcpState.endpoint || '';
  els.mcpEnabledCheckbox.checked = s.mcpEnabled;
  els.useNodeToolsCheckbox.checked = s.useNodeTools;
  els.autoToolCallsCheckbox.checked = s.autoToolCalls;
  els.toolCallRoundsInput.value = s.toolCallRounds;
  els.imageCaptionModelSelect.value = s.imageCaptionModel;
  els.refineCaptionWithLLMCheckbox.checked = s.refineCaptionWithLLM;
  els.disableWebGpuCheckbox.checked = s.disableWebGpu;
  els.themeSelect.value = s.theme;
  els.showMarkdownCheckbox.checked = s.showMarkdown;
  if (els.fontScaleSelect) els.fontScaleSelect.value = String(s.fontScale ?? 1);
  if (els.highContrastCheckbox) els.highContrastCheckbox.checked = !!s.highContrast;
  if (els.reduceMotionCheckbox) els.reduceMotionCheckbox.checked = !!s.reduceMotion;
  if (els.forceSearchToggle) {
    els.forceSearchToggle.checked = !!s.forceSearch;
    els.forceSearchToggle.setAttribute('aria-pressed', String(!!s.forceSearch));
  }
  // 読み上げボタンの aria-pressed
  els.ttsToggleBtn?.setAttribute('aria-pressed', String(speech.speakingEnabled));
  updateProviderVisibility();
  applyTheme();
  applyA11y();
}

function pullSettingsFromUI() {
  state.settings = {
    ...state.settings,
    provider: els.providerSelect.value,
    hfRepo: els.hfRepoInput.value.trim(),
    hfFile: els.hfFileSelect.value || DEFAULT_GGUF_FILE,
    localGgufFiles: Array.from(els.ggufUploadInput.files || []),
    webllmModel: els.webllmModelSelect.value,
    customWebllmRecord: els.customWebllmRecord.value.trim(),
    temperature: Number(els.temperatureInput.value || 0.7),
    maxTokens: Number(els.maxTokensInput.value || 768),
    topP: Number(els.topPInput.value || 0.9),
    contextBudget: Number(els.contextBudgetInput.value || 4096),
    systemPrompt: els.systemPromptInput.value.trim(),
    conversationRules: els.conversationRulesInput.value.trim(),
    allowSexualContent: els.allowSexualContentCheckbox.checked,
    allowViolence: els.allowViolenceCheckbox.checked,
    strictMedical: els.strictMedicalCheckbox.checked,
    aiModeration: els.aiModerationCheckbox.checked,
    useNodeModeration: els.useNodeModerationCheckbox.checked,
    blockUnsafeTts: els.blockUnsafeTtsCheckbox.checked,
    streamTts: els.streamTtsCheckbox.checked,
    maxTurns: Number(els.maxTurnsInput.value || 24),
    compressionStrategy: els.compressionStrategySelect.value,
    retrievalK: Number(els.retrievalKInput.value || 4),
    speechInputEngine: els.speechInputEngineSelect.value,
    ttsEngine: els.ttsEngineSelect.value,
    ttsVoiceURI: els.ttsVoiceSelect.value,
    ttsRate: Number(els.ttsRateInput.value || 1),
    ttsPitch: Number(els.ttsPitchInput.value || 1),
    mcpEndpoint: els.mcpEndpointInput.value.trim(),
    mcpEnabled: els.mcpEnabledCheckbox.checked,
    useNodeTools: els.useNodeToolsCheckbox.checked,
    autoToolCalls: els.autoToolCallsCheckbox.checked,
    toolCallRounds: Number(els.toolCallRoundsInput.value || 2),
    imageCaptionModel: els.imageCaptionModelSelect.value,
    refineCaptionWithLLM: els.refineCaptionWithLLMCheckbox.checked,
    disableWebGpu: els.disableWebGpuCheckbox.checked,
    theme: els.themeSelect.value,
    showMarkdown: els.showMarkdownCheckbox.checked,
    fontScale: Number(els.fontScaleSelect?.value || 1),
    highContrast: !!els.highContrastCheckbox?.checked,
    reduceMotion: !!els.reduceMotionCheckbox?.checked,
    forceSearch: els.forceSearchToggle ? els.forceSearchToggle.checked : (state.settings.forceSearch ?? false),
    searchTopK: state.settings.searchTopK ?? 6,
  };
  state.mcpState.endpoint = state.settings.mcpEndpoint;
  state.mcpState.enabled = state.settings.mcpEnabled;
  applyTheme();
  applyA11y();
  saveAll();
}

// ----------------- ツール集合 -----------------
function gatherTools() {
  const list = [];
  if (state.settings.useNodeTools && nodeTools.available) {
    list.push(...nodeTools.toolList());
  }
  if (state.settings.mcpEnabled && mcp.tools?.length) {
    list.push(...mcp.toolList());
  }
  state.toolsCatalog = list;
  return list;
}

async function invokeTool(name, args) {
  const inNode = nodeTools.tools?.some((t) => t.name === name);
  if (inNode && state.settings.useNodeTools) return await nodeTools.invoke(name, args);
  if (state.settings.mcpEnabled && mcp.tools?.some((t) => t.name === name)) {
    return await mcp.invokeTool(name, args);
  }
  throw new Error(`ツール ${name} が見つかりません`);
}

// ----------------- メッセージ描画 -----------------
const ROLE_LABEL = {
  user: 'あなた',
  assistant: 'AI',
  system: 'システム',
  notice: '通知',
  tool: 'ツール',
};

function renderMessages() {
  els.chatMessages.innerHTML = '';
  state.session.messages.forEach((message) => {
    const wrapper = document.createElement('article');
    wrapper.className = `message-bubble ${message.role}`;
    wrapper.dataset.id = message.id;
    wrapper.setAttribute('role', 'article');

    const roleLabel = ROLE_LABEL[message.role] || message.role;
    const notice = message.moderationNotice
      ? `<div class="badge bad" role="alert">${escapeHtml(message.moderationNotice)}</div>`
      : '';

    let body;
    if (!message.content && message.role === 'assistant' && state.generating) {
      body = `<span class="typing-dots" aria-label="AIが生成中"><span></span><span></span><span></span></span>`;
    } else if (state.settings.showMarkdown && (message.role === 'assistant' || message.role === 'tool')) {
      body = renderMarkdown(message.content || '');
    } else {
      body = escapeHtml(message.content || '');
    }

    const actions = (message.role === 'assistant')
      ? `<div class="message-actions">
           <button type="button" data-act="copy" aria-label="返答をコピー">📋 コピー</button>
           <button type="button" data-act="regen" aria-label="再生成">🔄 再生成</button>
           <button type="button" data-act="speak" aria-label="読み上げ">🔊 読み上げ</button>
         </div>`
      : '';

    wrapper.innerHTML = `
      <div class="message-meta">
        <span class="role-tag">${escapeHtml(roleLabel)}</span>
        <span>${escapeHtml(formatDateTime(message.createdAt))}</span>
      </div>
      ${notice}
      <div class="message-body">${body}</div>
      ${message.imageDataUrl ? `<img src="${message.imageDataUrl}" alt="添付画像" loading="lazy" />` : ''}
      ${actions}
    `;
    els.chatMessages.appendChild(wrapper);
  });
  // 自動スクロール (ユーザーが上にスクロール中でなければ)
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
}

els.chatMessages.addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-act]');
  if (!btn) return;
  const bubble = btn.closest('.message-bubble');
  const id = bubble?.dataset?.id;
  const msg = state.session.messages.find((m) => m.id === id);
  if (!msg) return;
  const act = btn.dataset.act;
  if (act === 'copy') {
    const ok = await copyText(msg.content || '');
    showToast(ok ? 'コピーしました' : 'コピーに失敗しました', ok ? 'good' : 'bad');
  } else if (act === 'speak') {
    speech.stopAllSpeech();
    speech.enqueueStreamingSpeech(msg.content || '', () => false);
  } else if (act === 'regen') {
    const idx = state.session.messages.findIndex((m) => m.id === id);
    const prevUser = [...state.session.messages.slice(0, idx)].reverse().find((m) => m.role === 'user');
    if (!prevUser) return showToast('再生成元のユーザー発話が見つかりません', 'bad');
    state.session.messages.splice(idx, 1);
    saveSession(state.session);
    renderMessages();
    sendMessage({ overrideText: (prevUser.content || '').replace(/^\[[^\]]*\]\s*/, '') });
  }
});

function addMessage(role, content, extra = {}) {
  const message = {
    id: createId('msg'),
    role, content,
    createdAt: new Date().toISOString(),
    ...extra,
  };
  state.session.messages.push(message);
  saveSession(state.session);
  renderMessages();
  return message;
}

function updateMessage(id, patch) {
  const m = state.session.messages.find((x) => x.id === id);
  if (!m) return;
  Object.assign(m, patch);
  saveSession(state.session);
  renderMessages();
}

function renderAttachmentPreview() {
  if (!state.pendingAttachment) {
    els.attachmentPreview.classList.add('hidden');
    els.attachmentPreview.innerHTML = '';
    return;
  }
  els.attachmentPreview.classList.remove('hidden');
  els.attachmentPreview.innerHTML = `
    <div class="message-meta">
      <span class="role-tag">添付予定</span>
      <button id="removeAttachmentBtn" type="button" class="secondary small-btn" aria-label="添付を削除">✕ 削除</button>
    </div>
    <img src="${state.pendingAttachment.dataUrl}" alt="添付プレビュー" />
    <p class="muted small">${escapeHtml(state.pendingAttachment.caption || '画像要約は未実行')}</p>
  `;
  $('#removeAttachmentBtn')?.addEventListener('click', () => {
    state.pendingAttachment = null;
    renderAttachmentPreview();
  });
}

// ----------------- HF GGUF 一覧 -----------------
async function refreshHfFiles() {
  const repo = els.hfRepoInput.value.trim();
  if (!repo) return;
  setModelStatus('Hugging Face のGGUF一覧を取得中');
  const res = await fetch(`https://huggingface.co/api/models/${repo}`);
  if (!res.ok) throw new Error(`Hugging Face API error: ${res.status}`);
  const data = await res.json();
  const files = (data.siblings || [])
    .map((x) => x.rfilename)
    .filter((n) => n?.toLowerCase?.().endsWith('.gguf'))
    .sort((a, b) => a.localeCompare(b));
  els.hfFileSelect.innerHTML = '';
  files.forEach((f) => {
    const o = document.createElement('option');
    o.value = f; o.textContent = f;
    els.hfFileSelect.appendChild(o);
  });
  const preferred = state.settings.hfFile || files[0] || '';
  if (files.includes(preferred)) els.hfFileSelect.value = preferred;
  else els.hfFileSelect.value = files[0] || '';
  setModelStatus(files.length ? `GGUF候補 ${files.length} 件` : 'GGUFファイルが見つかりません');
}

// ----------------- システム/履歴構築 -----------------
function buildSystemMessage() {
  const ruleText = buildPolicyPrompt(state.settings);
  const now = new Date().toISOString();
  const tools = gatherTools();
  const toolGuide = tools.length && state.settings.autoToolCalls
    ? buildToolGuide(tools, { autoMode: true })
    : '';
  const forceSearchNote = state.settings.forceSearch
    ? '【強制検索モード】現在ユーザーは「検索ON」を選択中です。これから提示されるWeb検索結果を主要な根拠として回答してください。検索結果が不十分なら、さらに[TOOL_CALL]で別のクエリで検索を足してから答えてください。'
    : '';
  return [
    state.settings.systemPrompt,
    '',
    '【会話ルール】',
    state.settings.conversationRules,
    '',
    '【追加ポリシー】',
    ruleText,
    '',
    toolGuide,
    forceSearchNote,
    `現在時刻(ISO8601): ${now}`,
    state.session.summary ? `会話要約:\n${state.session.summary}` : '',
  ].filter(Boolean).join('\n');
}

async function buildModelMessages(userText) {
  await maybeCompressHistory(userText);
  const retrievalQuery = [userText, state.pendingAttachment?.caption || ''].filter(Boolean).join('\n');
  const retrieved = await memory.retrieveRelevant(retrievalQuery, state.settings.retrievalK);
  const sysContent = buildSystemMessage();
  let budget = state.settings.contextBudget - estimateTokens(sysContent) - 400;
  const history = [];
  const recent = [...state.session.messages].reverse();
  for (const m of recent) {
    const rawContent = m.content || '';
    let role = m.role;
    let stamped;
    if (role === 'notice' || role === 'tool' || role === 'system') {
      if (role === 'system' && state.session.messages[0]?.id === m.id) continue;
      const label = role === 'tool' ? '[ツール結果]' : role === 'notice' ? '[通知]' : '[メモ]';
      stamped = `${label} ${rawContent}`;
      role = 'user';
    } else {
      stamped = rawContent;
    }
    const cost = estimateTokens(stamped);
    if (budget - cost < 0) break;
    history.push({ role, content: stamped });
    budget -= cost;
  }
  history.reverse();
  const memoryBlock = retrieved.length
    ? `関連メモリ:\n${retrieved.map((it, i) => `${i + 1}. ${it.text}`).join('\n')}`
    : '';
  const mergedSystem = [sysContent, memoryBlock].filter(Boolean).join('\n\n---\n\n');
  return [
    { role: 'system', content: mergedSystem },
    ...history,
  ];
}

function heuristicSummary(messages) {
  return messages.slice(0, 12)
    .map((m) => `${m.role}: ${(m.content || '').slice(0, 140)}`).join('\n');
}

async function collectOneShot(messages, maxTokens = 256) {
  let text = '';
  for await (const delta of state.adapterManager.streamChat(messages, {
    temperature: 0.2, topP: 0.9, maxTokens,
  })) text += delta;
  return text.trim();
}

async function maybeCompressHistory(triggerText = '') {
  const normal = state.session.messages.filter((m) => m.role === 'user' || m.role === 'assistant');
  const totalTokens = normal.reduce((s, m) => s + estimateTokens(m.content || ''), 0);
  const overTurns = normal.length > state.settings.maxTurns;
  const overTokens = totalTokens > state.settings.contextBudget * 1.15;
  if (!overTurns && !overTokens) return;

  const keep = Math.max(4, state.settings.maxTurns);
  const old = normal.slice(0, Math.max(0, normal.length - keep));
  if (!old.length) return;

  let summary = heuristicSummary(old);
  if (state.settings.compressionStrategy !== 'sliding-window' && state.adapterManager.isLoaded()) {
    try {
      summary = await collectOneShot([
        {
          role: 'system',
          content: '以下の会話を、ユーザーの嗜好・前提・未完タスク・重要な制約を保ちながら、日本語で簡潔に圧縮要約してください。推測は避け、箇条書き中心で。',
        },
        { role: 'user', content: old.map((m) => `${m.role}: ${m.content}`).join('\n') },
      ], 220);
    } catch { summary = heuristicSummary(old); }
  }

  state.session.summary = [state.session.summary, summary].filter(Boolean).slice(-2).join('\n\n');
  state.session.messages = state.session.messages.filter(
    (m) => !(m.role === 'user' || m.role === 'assistant') || !old.find((o) => o.id === m.id),
  );
  if (state.settings.compressionStrategy !== 'sliding-window') {
    await memory.addText(summary, { type: 'summary', source: 'history-compression' });
  }
  saveSession(state.session);
  renderMessages();
  if (triggerText) setComposerStatus('古い履歴を圧縮しました');
}

// ----------------- モデル -----------------
async function loadModel() {
  pullSettingsFromUI();
  setModelStatus('モデル読込を開始');
  showBusy('モデルを読み込み中…', {
    cancelable: true,
    onCancel: () => {
      state.adapterManager.stop();
      setModelStatus('読み込みをキャンセルしました');
    }
  });
  try {
    await state.adapterManager.load(state.settings, (s) => {
      setModelStatus(s);
      updateBusy(s);
    });
    setModelStatus(`準備完了: ${state.adapterManager.getLabel()}`);
    addMessage('notice', `モデル読込完了: ${state.adapterManager.getLabel()}`);
    showToast('モデルを読み込みました', 'good');
  } catch (e) {
    setModelStatus(`エラー: ${e.message}`);
    showToast(`モデル読込に失敗しました: ${e.message}`, 'bad');
  } finally {
    hideBusy();
  }
}

// ----------------- MCP / Node ツール -----------------
async function connectMcp() {
  pullSettingsFromUI();
  mcp.setEndpoint(state.settings.mcpEndpoint);
  try {
    const tools = await mcp.connect();
    state.mcpState = { endpoint: state.settings.mcpEndpoint, enabled: state.settings.mcpEnabled, tools };
    saveMcpState(state.mcpState);
    addMessage('notice', `MCP接続: ${tools.length} 個のツールを検出`);
    showToast('MCPに接続しました', 'good');
  } catch (e) {
    showToast(`MCP接続に失敗しました: ${e.message}`, 'bad');
  } finally {
    renderToolsList();
  }
}

function renderToolsList() {
  const tools = gatherTools();
  if (!tools.length) {
    els.mcpToolsList.textContent = '未接続（同梱Nodeが起動していれば自動検出されます）';
    return;
  }
  els.mcpToolsList.textContent = tools.map((t) => `• [${t.origin}] ${t.name}${t.description ? ` — ${t.description}` : ''}`).join('\n');
}

async function handleMcpCommand(rawText) {
  const m = rawText.match(/^\/mcp\s+(\S+)\s*(.*)$/);
  if (!m) return false;
  const [, toolName, argText] = m;
  try {
    const args = argText ? JSON.parse(argText) : {};
    const result = await invokeTool(toolName, args);
    addMessage('tool', `**${toolName}** 実行結果:\n\n\`\`\`json\n${JSON.stringify(result, null, 2)}\n\`\`\``);
    if (JSON.stringify(result).length < 4000) {
      await memory.addText(JSON.stringify(result), { type: 'mcp-result', source: toolName });
    }
  } catch (e) {
    addMessage('notice', `ツール実行エラー: ${e.message}`);
  }
  return true;
}

// ----------------- モデレーション 統合 -----------------
async function moderateFinal(text) {
  const heuristic = moderateText(text, state.settings, { mode: 'final' });
  if (state.settings.useNodeModeration && nodeTools.available) {
    try {
      const r = await nodeTools.moderateExternal(text);
      if (r?.available) {
        if (String(r.verdict).toUpperCase() === 'BLOCK') {
          return {
            blocked: true,
            issues: [...new Set([...(heuristic.issues || []), 'ai-block'])],
            meta: { ...(heuristic.meta || {}), aiReason: r.reason || '' },
          };
        }
        if (String(r.verdict).toUpperCase() === 'ALLOW') {
          return {
            blocked: false,
            issues: (heuristic.issues || []).filter((x) => !['sexual-soft', 'violence-soft'].includes(x)),
            meta: { ...(heuristic.meta || {}), aiReason: r.reason || '' },
          };
        }
      }
    } catch { /* fallthrough */ }
  }
  if (state.settings.aiModeration && state.adapterManager.isLoaded()) {
    return await aiModerate({
      text, settings: state.settings, heuristic,
      runOneShot: (msgs, max) => collectOneShot(msgs, max),
    });
  }
  return heuristic;
}

// ----------------- 送信本体 -----------------
async function sendMessage({ overrideText } = {}) {
  const text = (overrideText ?? els.messageInput.value).trim();
  if (!text && !state.pendingAttachment) return;
  if (!state.adapterManager.isLoaded()) {
    addMessage('notice', '先にモデルを読み込んでください。サイドバーの「モデル」セクションで読込ボタンを押してください。');
    return;
  }
  if (state.generating) return;
  pullSettingsFromUI();

  if (await handleMcpCommand(text)) {
    els.messageInput.value = '';
    return;
  }

  state.generating = true;
  els.sendBtn.disabled = true;
  speech.stopAllSpeech();
  setComposerStatus('送信中…');

  const attCaption = state.pendingAttachment?.caption
    ? `\n\n[添付画像の要約]\n${state.pendingAttachment.caption}`
    : state.pendingAttachment ? '\n\n[添付画像あり]' : '';

  const userMessage = addMessage('user', `${text}${attCaption}`, {
    imageDataUrl: state.pendingAttachment?.dataUrl || '',
  });
  if (!overrideText) els.messageInput.value = '';

  await memory.extractAndStoreFacts(userMessage.content, 'user-message');

  if (state.settings.forceSearch && nodeTools.available && state.settings.useNodeTools && text) {
    setComposerStatus('強制検索モード: Web検索中…');
    try {
      const r = await nodeTools.webSearch(text, state.settings.searchTopK || 6);
      const lines = (r.results || []).map((x, i) =>
        `${i + 1}. [${x.title}](${x.url})\n   ${x.snippet}`).join('\n');
      addMessage('tool', `**web_search** (自動): ${text}\n\n${lines || '結果なし'}`);
      if (lines) await memory.addText(`Web検索 q=${text}\n${lines}`, { type: 'web-search', source: 'force' });
    } catch (e) {
      addMessage('notice', `自動検索失敗: ${e.message} — 検索なしで回答を続行します。`);
    }
  }

  const maxRounds = Math.max(1, state.settings.toolCallRounds || 1);
  let toolRound = 0;
  let assistantMessage = null;
  let fullText = '';

  try {
    while (true) {
      assistantMessage = addMessage('assistant', '');
      const modelMessages = await buildModelMessages(text);
      modelMessages.push({ role: 'user', content: userMessage.content });

      fullText = '';
      let speechBuffer = '';
      setComposerStatus(toolRound === 0 ? '生成中…' : `ツール結果反映中 (${toolRound + 1}回目)…`);

      for await (const delta of state.adapterManager.streamChat(modelMessages, {
        temperature: state.settings.temperature,
        topP: state.settings.topP,
        maxTokens: state.settings.maxTokens,
      })) {
        fullText += delta;
        updateMessage(assistantMessage.id, { content: fullText });

        if (state.settings.streamTts) {
          speechBuffer += delta;
          if (/[。！？!?]\s*$/.test(speechBuffer) || speechBuffer.length > 90) {
            const shouldBlock = (piece) => state.settings.blockUnsafeTts &&
              moderateText(piece, state.settings, { mode: 'stream' }).blocked;
            speech.enqueueStreamingSpeech(speechBuffer, shouldBlock);
            speechBuffer = '';
          }
        }
      }
      if (speechBuffer && state.settings.streamTts) {
        const shouldBlock = (piece) => state.settings.blockUnsafeTts &&
          moderateText(piece, state.settings, { mode: 'stream' }).blocked;
        speech.enqueueStreamingSpeech(speechBuffer, shouldBlock);
      }

      const call = state.settings.autoToolCalls ? parseToolCall(fullText) : null;
      if (call && toolRound < maxRounds) {
        toolRound += 1;
        addMessage('notice', `ツール実行: ${call.name} ${JSON.stringify(call.arguments).slice(0, 240)}`);
        let result;
        try {
          result = await invokeTool(call.name, call.arguments || {});
        } catch (e) {
          result = { error: e.message };
        }
        const serialized = typeof result === 'string' ? result : JSON.stringify(result, null, 2);
        addMessage('tool', `**${call.name}** の結果:\n\n\`\`\`json\n${serialized.slice(0, 4000)}\n\`\`\``);
        if (serialized.length < 6000) {
          await memory.addText(serialized.slice(0, 4000), { type: 'tool-result', source: call.name });
        }
        continue;
      }

      setComposerStatus('安全性チェック中…');
      const moderation = await moderateFinal(fullText);
      if (moderation.blocked) {
        speech.stopAllSpeech();
        updateMessage(assistantMessage.id, {
          content: '',
          moderationNotice: renderModerationNotice(moderation),
        });
      } else {
        let finalText = fullText;
        if (moderation.issues.includes('medical-caution')) {
          finalText += '\n\n※ 専門的な判断が必要な可能性があります。必要に応じて専門家にも相談してください。';
        }
        updateMessage(assistantMessage.id, {
          content: finalText,
          moderationNotice: moderation.issues?.length && !moderation.blocked
            ? renderModerationNotice(moderation) : '',
        });
        await memory.extractAndStoreFacts(finalText, 'assistant-message');
        if (!state.settings.streamTts && speech.speakingEnabled && !moderation.blocked) {
          speech.enqueueStreamingSpeech(finalText, () => false);
        }
      }
      break;
    }
  } catch (e) {
    if (assistantMessage) updateMessage(assistantMessage.id, { content: `エラー: ${e.message}` });
    else addMessage('notice', `エラー: ${e.message}`);
  } finally {
    state.pendingAttachment = null;
    renderAttachmentPreview();
    state.generating = false;
    els.sendBtn.disabled = false;
    setComposerStatus('準備完了');
    saveAll();
  }
}

// ----------------- 音声入力 -----------------
async function handleMic() {
  pullSettingsFromUI();
  if (!state.micActive) {
    state.micActive = true;
    els.micBtn.innerHTML = '<span aria-hidden="true">⏹</span> 停止';
    els.micBtn.setAttribute('aria-pressed', 'true');
    setComposerStatus('音声入力中…');
    if (state.settings.speechInputEngine === 'browser') {
      speech.startBrowserRecognition((t) => { els.messageInput.value = t; });
    } else {
      await speech.startRecorder();
    }
    return;
  }
  state.micActive = false;
  els.micBtn.innerHTML = '<span aria-hidden="true">🎤</span> 音声';
  els.micBtn.setAttribute('aria-pressed', 'false');
  if (state.settings.speechInputEngine === 'browser') {
    speech.stopBrowserRecognition();
  } else {
    els.messageInput.value = await speech.stopRecorderAndTranscribe();
  }
  setComposerStatus('音声入力完了');
}

// ----------------- 画像 -----------------
async function handleImageInput(file) {
  if (!file) return;
  const dataUrl = await new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
  state.pendingAttachment = { type: 'image', dataUrl, caption: '' };
  renderAttachmentPreview();
}

async function describePendingImage() {
  if (!state.pendingAttachment?.dataUrl) {
    addMessage('notice', '先に画像を添付してください。');
    return;
  }
  setComposerStatus('画像要約中…');
  const refine = state.settings.refineCaptionWithLLM && state.adapterManager.isLoaded()
    ? async (en) => {
        try {
          return await collectOneShot([
            { role: 'system', content: '次の画像キャプションを日本語で、もう少し詳しく、自然な文に書き直してください。短く2〜3文。' },
            { role: 'user', content: en },
          ], 160);
        } catch { return en; }
      }
    : null;
  try {
    const caption = await images.describeImage(state.pendingAttachment.dataUrl, {
      modelId: state.settings.imageCaptionModel,
      refine,
    });
    state.pendingAttachment.caption = caption;
    renderAttachmentPreview();
    await memory.addText(caption, { type: 'image-caption', source: 'attachment' });
    setComposerStatus('画像要約完了');
  } catch (e) {
    showToast(`画像要約エラー: ${e.message}`, 'bad');
    setComposerStatus('画像要約に失敗しました');
  }
}

async function toggleCamera() {
  if (!state.cameraActive) {
    await images.startCamera(els.cameraPreview);
    state.cameraActive = true;
    els.cameraBtn.innerHTML = '<span aria-hidden="true">📸</span> 撮影';
    els.cameraPreview.classList.remove('hidden');
    return;
  }
  const dataUrl = images.captureFromVideo(els.cameraPreview);
  images.stopCamera(els.cameraPreview);
  state.cameraActive = false;
  els.cameraBtn.innerHTML = '<span aria-hidden="true">📷</span> カメラ';
  els.cameraPreview.classList.add('hidden');
  state.pendingAttachment = { type: 'image', dataUrl, caption: '' };
  renderAttachmentPreview();
}

// ----------------- Web 検索 -----------------
async function quickWebSearch() {
  if (!nodeTools.available) {
    showToast('Node ツールが起動していません。npm run start などでサーバーを起動してください。', 'bad');
    return;
  }
  const q = els.messageInput.value.trim();
  if (!q) return showToast('検索したい語句を入力してください', 'warn');
  setComposerStatus('検索中…');
  try {
    const r = await nodeTools.webSearch(q, 6);
    const lines = (r.results || []).map((x, i) => `${i + 1}. [${x.title}](${x.url})\n   ${x.snippet}`).join('\n');
    addMessage('tool', `**web_search**: ${q}\n\n${lines || '結果なし'}`);
    await memory.addText(`Web検索 q=${q}\n${lines}`, { type: 'web-search', source: 'manual' });
    setComposerStatus('検索完了');
  } catch (e) {
    showToast(`検索失敗: ${e.message}`, 'bad');
    setComposerStatus('検索失敗');
  }
}

// ----------------- 入出力 -----------------
function exportData() {
  pullSettingsFromUI();
  downloadJson('chatai-browser-studio-export.json', {
    app: APP_NAME, version: APP_VERSION,
    exportedAt: new Date().toISOString(),
    settings: state.settings,
    session: state.session,
    knowledgeBase: state.knowledgeBase,
    mcpState: state.mcpState,
  });
  showToast('データを保存しました', 'good');
}

async function importData(file) {
  if (!file) return;
  const text = await file.text();
  let data;
  try { data = JSON.parse(text); }
  catch (e) { throw new Error(`JSON が読めません: ${e.message}`); }

  // 設定の統合
  state.settings = { ...DEFAULT_SETTINGS, ...(data.settings || {}) };

  // セッションの正規化（messages.map エラー防止）
  state.session = normalizeSession(data.session || state.session);

  // 知識ベースとMCP状態の統合（最低限の形式チェック）
  if (data.knowledgeBase && Array.isArray(data.knowledgeBase.items)) {
    state.knowledgeBase = data.knowledgeBase;
  }
  if (data.mcpState && typeof data.mcpState === 'object') {
    state.mcpState = data.mcpState;
  }

  applySettingsToUI();
  saveAll();
  renderMessages();
  renderToolsList();
  showToast('データを読み込みました', 'good');
}

function resetChat({ silent = false } = {}) {
  if (!silent && !confirm('会話履歴をリセットします。よろしいですか？\n(添付画像・要約・キャッシュも消えます)')) return;
  state.session.messages = state.session.messages.filter((m) => m.role === 'system').slice(0, 1);
  state.session.summary = '';
  saveSession(state.session);
  renderMessages();
  speech.stopAllSpeech();
  if (!silent) showToast('会話をリセットしました', 'good');
}

// ----------------- 設定ダイアログ + 履歴管理 -----------------
function openSettings() {
  if (state.settingsOpen) return;
  state.settingsOpen = true;
  els.settingsDialog.showModal();
  // 戻るボタンで閉じられるように
  try { history.pushState({ modal: 'settings' }, ''); } catch {}
}
function closeSettings({ fromPop = false } = {}) {
  if (!state.settingsOpen) return;
  state.settingsOpen = false;
  if (els.settingsDialog.open) els.settingsDialog.close();
  if (!fromPop) {
    try { if (history.state?.modal === 'settings') history.back(); } catch {}
  }
}

// ----------------- ショートカット -----------------
function setupShortcuts() {
  document.addEventListener('keydown', (e) => {
    const target = e.target;
    const isText = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);

    // Escape: ダイアログ / サイドバー / 生成停止
    if (e.key === 'Escape') {
      if (state.settingsOpen) { closeSettings(); return; }
      if (state.sidebarOpen) { setSidebar(false); return; }
      if (state.generating) {
        state.adapterManager.stop();
        speech.stopAllSpeech();
        setComposerStatus('生成を停止しました');
        return;
      }
    }

    if (!(e.ctrlKey || e.metaKey)) return;

    // Ctrl+, 設定
    if (e.key === ',') {
      e.preventDefault();
      state.settingsOpen ? closeSettings() : openSettings();
      return;
    }
    // Ctrl+K 検索
    if (e.key.toLowerCase() === 'k') {
      e.preventDefault();
      quickWebSearch();
      return;
    }
    // Ctrl+L チャットへフォーカス
    if (e.key.toLowerCase() === 'l') {
      e.preventDefault();
      els.messageInput.focus();
      return;
    }
    // Ctrl+/ サイドバー開閉
    if (e.key === '/') {
      e.preventDefault();
      setSidebar(!state.sidebarOpen);
      return;
    }
  });

  // 戻るボタンで設定ダイアログ・サイドバーを閉じる
  window.addEventListener('popstate', (e) => {
    if (state.settingsOpen) closeSettings({ fromPop: true });
    if (state.sidebarOpen) setSidebar(false);
  });
}

// ----------------- 初期化 -----------------
async function init() {
  populateWebllmModels();
  populateGgufPresets();
  populateCaptionModels();
  applySettingsToUI();
  populateVoices();
  renderMessages();
  renderAttachmentPreview();
  await updateCapabilityBadges();
  renderToolsList();
  setupShortcuts();

  window.speechSynthesis?.addEventListener?.('voiceschanged', populateVoices);

  // モバイル UI
  els.openSidebarBtn?.addEventListener('click', () => setSidebar(true));
  els.closeSidebarBtn?.addEventListener('click', () => setSidebar(false));
  els.sidebarBackdrop?.addEventListener('click', () => setSidebar(false));
  els.themeToggleBtn?.addEventListener('click', () => {
    const order = ['auto', 'dark', 'light'];
    const i = order.indexOf(state.settings.theme || 'auto');
    state.settings.theme = order[(i + 1) % order.length];
    els.themeSelect.value = state.settings.theme;
    applyTheme();
    saveSettings(state.settings);
    showToast(`テーマ: ${state.settings.theme === 'auto' ? '自動' : state.settings.theme === 'dark' ? 'ダーク' : 'ライト'}`);
  });

  // モデル
  els.providerSelect.addEventListener('change', () => { updateProviderVisibility(); pullSettingsFromUI(); });
  els.loadModelBtn.addEventListener('click', () => loadModel());
  els.stopGenerationBtn.addEventListener('click', () => {
    state.adapterManager.stop();
    speech.stopAllSpeech();
    setComposerStatus('生成を停止しました');
  });
  els.clearChatBtn.addEventListener('click', () => resetChat());
  $('#resetChatBtn')?.addEventListener('click', () => resetChat());
  els.refreshFilesBtn.addEventListener('click', () =>
    refreshHfFiles().catch((e) => {
      setModelStatus(`エラー: ${e.message}`);
      showToast(`一覧取得に失敗しました: ${e.message}`, 'bad');
    })
  );
  els.ggufPresetSelect.addEventListener('change', async () => {
    const v = els.ggufPresetSelect.value;
    if (!v) return;
    try {
      const obj = JSON.parse(v);
      els.hfRepoInput.value = obj.repo;
      state.settings.hfRepo = obj.repo;
      state.settings.hfFile = obj.file;
      await refreshHfFiles();
      const opt = Array.from(els.hfFileSelect.options).find((o) => o.value === obj.file);
      if (opt) els.hfFileSelect.value = obj.file;
      pullSettingsFromUI();
    } catch (e) {
      showToast(`プリセット読込失敗: ${e.message}`, 'bad');
    }
  });

  // 送信
  els.sendBtn.addEventListener('click', () => sendMessage());
  els.messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      sendMessage();
    }
  });

  // メディア
  els.micBtn.addEventListener('click', () =>
    handleMic().catch((e) => {
      setComposerStatus(`音声入力エラー: ${e.message}`);
      showToast(`音声入力エラー: ${e.message}`, 'bad');
    })
  );
  els.imageInput.addEventListener('change', (e) =>
    handleImageInput(e.target.files?.[0]).catch?.((err) => showToast(`画像読込エラー: ${err.message}`, 'bad'))
  );
  els.describeImageBtn.addEventListener('click', () => describePendingImage());
  els.cameraBtn.addEventListener('click', () =>
    toggleCamera().catch((e) => {
      setComposerStatus(`カメラエラー: ${e.message}`);
      showToast(`カメラエラー: ${e.message}`, 'bad');
    })
  );
  els.webSearchBtn.addEventListener('click', () => quickWebSearch());

  // I/O
  els.exportBtn?.addEventListener('click', exportData);
  els.importInput?.addEventListener('change', (e) =>
    importData(e.target.files?.[0]).catch((err) => {
      addMessage('notice', `読込エラー: ${err.message}`);
      showToast(`読込エラー: ${err.message}`, 'bad');
    })
  );

  // 設定
  els.toggleSettingsBtn?.addEventListener('click', () => openSettings());
  els.settingsDialog?.addEventListener('close', () => { state.settingsOpen = false; });

  // 読み上げ
  els.ttsToggleBtn.addEventListener('click', () => {
    speech.speakingEnabled = !speech.speakingEnabled;
    els.ttsToggleBtn.setAttribute('aria-pressed', String(speech.speakingEnabled));
    if (!speech.speakingEnabled) speech.stopAllSpeech();
    showToast(`読み上げ: ${speech.speakingEnabled ? 'ON' : 'OFF'}`);
  });

  // MCP
  els.connectMcpBtn.addEventListener('click', () => connectMcp());

  // 知識
  els.addKnowledgeBtn.addEventListener('click', async () => {
    const text = els.knowledgeInput.value.trim();
    if (!text) return showToast('保存するテキストが空です', 'warn');
    setComposerStatus('知識を保存中…');
    try {
      await memory.addText(text, { type: 'manual', source: 'textarea' });
      els.knowledgeInput.value = '';
      els.ragStatus.textContent = `知識片数: ${state.knowledgeBase.items.length}`;
      setComposerStatus('保存完了');
      showToast('知識を保存しました', 'good');
    } catch (e) {
      showToast(`保存に失敗しました: ${e.message}`, 'bad');
    }
  });
  els.rebuildEmbeddingsBtn.addEventListener('click', async () => {
    setComposerStatus('埋め込み再計算中…');
    showBusy('埋め込みを再計算中…');
    try {
      const n = await memory.rebuildAllEmbeddings();
      els.ragStatus.textContent = `再計算完了: ${n} 件`;
      setComposerStatus('再計算完了');
      showToast(`埋め込み再計算 完了: ${n}件`, 'good');
    } catch (e) {
      showToast(`再計算に失敗しました: ${e.message}`, 'bad');
    } finally {
      hideBusy();
    }
  });
  els.summarizeNowBtn.addEventListener('click', () =>
    maybeCompressHistory('manual').catch((e) => addMessage('notice', `要約エラー: ${e.message}`))
  );
  els.fetchUrlBtn.addEventListener('click', async () => {
    const url = els.ragUrlInput.value.trim();
    if (!url) return showToast('URL を入力してください', 'warn');
    setComposerStatus('URL取得中…');
    try {
      let text;
      if (nodeTools.available && state.settings.useNodeTools) {
        const r = await nodeTools.fetchUrl(url);
        text = `# ${r.title || url}\n\n${r.text}`;
      } else {
        text = await safeFetchText(url);
      }
      await memory.addText(text, { type: 'url', source: url });
      els.ragStatus.textContent = `URL保存完了: ${url}`;
      setComposerStatus('URL保存完了');
      showToast('URLを保存しました', 'good');
    } catch (e) {
      showToast(`URL取得失敗: ${e.message}`, 'bad');
      setComposerStatus('URL取得失敗');
    }
  });

  // 検索ON/OFF
  els.forceSearchToggle?.addEventListener('change', () => {
    const next = !!els.forceSearchToggle.checked;
    state.settings.forceSearch = next;
    saveSettings(state.settings);
    showToast(`検索必須モード: ${next ? 'ON (必ず検索してから回答)' : 'OFF (必要時のみ)'}`, next ? 'good' : '');
  });

  // 設定一括反映
  document.querySelectorAll('input, select, textarea').forEach((el) => {
    el.addEventListener('change', pullSettingsFromUI);
  });

  if (state.settings.provider === 'wllama') {
    try { await refreshHfFiles(); }
    catch { setModelStatus('GGUF一覧は手動更新できます'); }
  }

  // 初期フォーカス: 入力欄に
  setTimeout(() => els.messageInput?.focus(), 80);
}

init().catch((e) => {
  addMessage('notice', `初期化エラー: ${e.message}`);
});
