# ChatAI Browser Studio v2.1.0

WebGPU / GGUF / RAG / 音声 / 画像 / MCP / Web検索 をすべてブラウザで動かす、ローカルAIスタジオ。

## 起動

```bash
node server.mjs
```

- 証明書 (`*.pem`) が同じディレクトリにあれば **HTTPS** で起動 (https://localhost:8080)
- 証明書が無い場合は自動的に **HTTP** で起動 (http://localhost:8080)
- 環境変数:
  - `PORT` (既定 8080) / `HOST` (既定 0.0.0.0)
  - `LLM_BASE_URL` / `LLM_API_KEY` / `LLM_MODEL` … 外部LLMをモデレーション中継に使う場合のみ（OpenAI互換 `/v1`）

## v2.1.0 (v7) 修正点

### 🔧 致命的バグ修正
1. **`defaults.js` 構文エラーの修正**
   不要な bash スクリプトの記述を削除し、ローディングが止まらない問題を解消。
2. **`messages.map is not a function` エラーの修正**
   インポート時やセッション読み込み時のデータ正規化を徹底し、不正なデータ形式によるクラッシュを防止。
3. **`PathError: Missing parameter name at index 22: /vendor/transformers/*`**
   Express 5 系の `path-to-regexp` 仕様変更に対応し、ルートを正規表現ベースに変更。
4. **証明書が無い環境でも起動できないバグ**
   `*.pem` が無ければ自動で **HTTP にフォールバック**。
5. 404 ハンドラを Express 5 互換に修正。
6. 静的ファイルの Cache-Control を適切に設定。

### 🛡️ セキュリティ耐性強化 (外部公開準備)
- **簡易レート制限の実装**: `/api/` への過剰なリクエストを IP ごとに制限 (15分100回)。
- **CSP (Content Security Policy) の強化**: 不要な外部接続を制限し、XSS 耐性を向上。
- **セキュリティヘッダの追加**: `X-Content-Type-Options`, `X-Frame-Options`, `X-XSS-Protection` を適切に設定。
- **CORS の調整**: 開発の利便性を保ちつつ、将来のオリジン制限が容易な構成に。

### 🎨 UI / UX 全面改善 (「考えなくても使えるデザイン」)
- **配色刷新**: フラットで高コントラストな配色に。背景の半透明 / blur を排除し読みやすさ最優先。
- **ボタンの視認性**:
  - 主要ボタンは `linear-gradient` で他と差別化、 secondary は明確な枠線。
  - すべてのインタラクティブ要素に `focus-visible` で 3px のフォーカスリング。
  - タップターゲット最小 38px (モバイル 44px)。
- **ローディング表示**:
  - モデル読込・埋め込み再計算でグローバル `busy-overlay` 表示 (進捗テキスト + キャンセル可)。
  - AI 生成中はチャットバブル内に**タイピングインジケータ** (3 つの点アニメ)。
- **タイミング / 状態表示**:
  - composer 下に「準備完了 / 送信中 / 生成中 / 安全性チェック中 / 完了」を逐次表示。
  - メッセージごとに「あなた / AI / 通知 / ツール」のラベル表示。
- **エラーメッセージの改善**: トーストはアイコン (✓ / ✕ / !) + 左ボーダーカラーで色覚多様性に配慮。本文も「〜に失敗しました」と能動的に。

### ♿ アクセシビリティ
- **キーボード操作**:
  - <kbd>Enter</kbd> 送信 / <kbd>Shift</kbd>+<kbd>Enter</kbd> 改行
  - <kbd>Ctrl</kbd>+<kbd>,</kbd> 設定 / <kbd>Ctrl</kbd>+<kbd>K</kbd> Web検索 / <kbd>Ctrl</kbd>+<kbd>L</kbd> 入力欄 / <kbd>Ctrl</kbd>+<kbd>/</kbd> サイドバー / <kbd>Esc</kbd> ダイアログ閉じる・生成停止
- **スクリーンリーダー対応**: 全ボタンに `aria-label` / `aria-pressed` / `aria-expanded`、ライブリージョン (`aria-live`)、`role="log"` のチャット、スキップリンクを追加。
- **色覚多様性**: badge は色だけでなく形 (●▲■) + テキストで状態を伝える。
- **文字サイズ変更**: 設定 → 表示 → 文字サイズ (小 / 標準 / 大 / 特大)。
- **高コントラストモード**: 設定 → 表示 → 高コントラストモード (白黒ベースに切替)。
- **アニメーション抑制**: 設定 → 表示 → アニメーションを抑制 (および `prefers-reduced-motion` を尊重)。

### 📱 レスポンシブ
- 1100px 以下: サイドバーがドロワーに切替、モバイル上部バー表示。
- 720px 以下: タップ対象を 44px に、Composer ツールバーを縦折り返し、フォントを少し縮小、設定ダイアログを 1 列に。
- iOS Safe Area (`env(safe-area-inset-*)`) 対応。

### 🔁 戻るボタンで壊れない
- 設定ダイアログを開くと `history.pushState`、戻るボタンや <kbd>Esc</kbd> で `history.back` → ダイアログを閉じる。
- サイドバーも `popstate` 時に自動で閉じる。

### 🌓 ダークモード
- 自動 (OSに従う) / ダーク / ライト を切り替え。`<meta name="theme-color">` でブラウザ chrome も連動。

### ⚡ パフォーマンス
- 背景の `backdrop-filter` 大量使用をやめ、描画コストを大幅削減。
- Service Worker の戦略を更新:
  - HTML / JS / CSS は **network-first** (常に最新版を取得、オフライン時のみキャッシュ)。
  - その他同一オリジンリソースは cache-first。
  - `/vendor/` はキャッシュしない (動的書換のため)。
- リンク `preconnect` で初回接続のレイテンシ削減。

### 🌐 ブラウザ対応
- 最新版 Chrome / Edge / Firefox / Safari で動作確認可能な書き方に。
- `:has()` を使う部分はトグルボタンのみ (フォールバック許容)。
- `color-mix(in srgb, ...)` をベースカラー演算に使用 (Chromium 111+ / Firefox 113+ / Safari 16.4+)。古い環境ではフォールバック色が出る程度で機能は維持。

---

## v2 で改善されたこと (継続)

### モデレーションの誤検知抑制
- 強シグナル / 弱シグナル / benign 文脈の分離。
- AI による二次判定 (ローカルLLM or 外部LLM)。
- OD / オーバードーズは本人の意志表明でのみ自傷扱い。

### Node 側ツール (同梱)
- `POST /api/tools/web_search` (DuckDuckGo / Bing fallback)
- `POST /api/tools/fetch_url`
- `POST /api/tools/moderate`
- `GET  /api/tools/list`
- `GET  /api/health`
- `GET  /vendor/transformers/*` / `/vendor/esm/*` (esm.sh 同一オリジンプロキシ)

### モデルからの自動ツール呼び出し
```
[TOOL_CALL]{"name":"web_search","arguments":{"query":"WebGPU news"}}[/TOOL_CALL]
```
最大ラウンド数を設定で変更可能 (既定 4)。

### 分割GGUF / 画像理解 / PWA
（変更なし。引き続き対応）

## ツール手動呼出

チャット欄でも直接呼べます:

```
/mcp web_search {"query":"WebGPU news"}
/mcp fetch_url {"url":"https://example.com"}
```

## API リクエスト例

```bash
curl -s -X POST http://localhost:8080/api/tools/web_search \
  -H 'Content-Type: application/json' \
  -d '{"query":"GGUF wllama","max":5}'
```

## トラブルシューティング

- **`Missing parameter name at index ...`** → 旧 `server.mjs` のバグ。本バージョンで解消済み。
- **モデル読込が固まる** → 設定 → ハードウェア → 「WebGPU を無効化」をONにして再読込。
- **DuckDuckGo CAPTCHA で検索失敗** → 自動的に Bing へフォールバック。
- **HTTPS で起動したい** → mkcert などで `localhost.pem` / `localhost-key.pem` を作成し、`server.mjs` と同じディレクトリに置く。
