/* ChatAI Browser Studio — Service Worker (v7)
 *  - アプリシェルを precache
 *  - CDN (esm.sh / jsdelivr / huggingface) は SWR
 *  - /api/* は network-only
 */
const VERSION = 'v2.1.0';
const APP_SHELL = [
  './',
  './index.html',
  './styles.css',
  './manifest.webmanifest',
  './js/app.js',
  './js/config.js',
  './js/defaults.js',
  './js/adapters.js',
  './js/media.js',
  './js/memory.js',
  './js/mcp.js',
  './js/node-tools.js',
  './js/rules.js',
  './js/storage.js',
  './js/utils.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(`shell-${VERSION}`).then((c) => c.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => !k.endsWith(VERSION)).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

function isCDN(url) {
  return /(esm\.sh|cdn\.jsdelivr\.net|huggingface\.co)/.test(url.host);
}

function shouldSkipCache(url) {
  return (
    url.pathname.endsWith('.gguf') ||
    url.pathname.endsWith('.bin') ||
    url.pathname.endsWith('.onnx') ||
    url.pathname.includes('/resolve/main/') ||
    url.searchParams.has('range')
  );
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // API は常にネットワーク
  if (url.pathname.startsWith('/api/')) return;
  // /vendor も毎回ネットワーク (動的書換のため)
  if (url.pathname.startsWith('/vendor/')) return;

  // 同一オリジン: network-first ですぐ最新版 (HTML/JS/CSS)
  if (url.origin === self.location.origin) {
    if (req.destination === 'document' || /\.(?:html|js|css|webmanifest)$/.test(url.pathname)) {
      event.respondWith((async () => {
        const cache = await caches.open(`shell-${VERSION}`);
        try {
          const res = await fetch(req, { cache: 'no-store' });
          if (res.ok) cache.put(req, res.clone()).catch(() => {});
          return res;
        } catch {
          const cached = await cache.match(req);
          return cached || new Response('Offline', { status: 503, statusText: 'Offline' });
        }
      })());
      return;
    }
    // 画像など: cache-first
    event.respondWith((async () => {
      const cache = await caches.open(`shell-${VERSION}`);
      const cached = await cache.match(req);
      const network = fetch(req).then((res) => {
        if (res.ok) cache.put(req, res.clone()).catch(() => {});
        return res;
      }).catch(() => cached);
      return cached || network;
    })());
    return;
  }

  // CDN: SWR
  if (isCDN(url)) {
    if (shouldSkipCache(url)) return;
    event.respondWith((async () => {
      const cache = await caches.open(`cdn-${VERSION}`);
      const cached = await cache.match(req);
      const update = fetch(req).then((res) => {
        const len = res.headers.get('content-length');
        const isSmall = !len || parseInt(len) < 10 * 1024 * 1024;
        if (res.ok && isSmall) {
          cache.put(req, res.clone()).catch(() => {});
        }
        return res;
      }).catch(() => cached);
      return cached || update;
    })());
  }
});
